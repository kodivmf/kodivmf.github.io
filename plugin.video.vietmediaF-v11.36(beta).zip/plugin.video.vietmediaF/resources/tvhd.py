import requests
from bs4 import BeautifulSoup
import re, os, json
import hashlib
import urllib.parse
from resources import fshare, cache_utils
import htmlement
from resources.addon import alert, notify, TextBoxes, ADDON, ADDON_ID, CACHE_PATH, addon_url
import xbmcgui, xbmc, xbmcvfs
from concurrent.futures import ThreadPoolExecutor
import threading

from collections import OrderedDict
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from requests.exceptions import ConnectionError, Timeout, RequestException



def create_session():
    session = requests.Session()


    retry_strategy = Retry(
        total=3,
        backoff_factor=0.5,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST", "HEAD"]
    )


    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)


    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.0.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Connection": "keep-alive"
    })

    return session


session = create_session()

def search(page, query):
    search_url = "https://thuvienhd.top/page/%s?s=%s" % (page, query)


    cache_key = hashlib.md5(search_url.encode()).hexdigest() + "_search"


    if cache_utils.check_cache(cache_key, 30):
        cache_data = cache_utils.get_cache(cache_key)
        if cache_data:

            return cache_data




    try:

        response = session.get(search_url, verify=False, timeout=30)
        response.raise_for_status()
    except (ConnectionError, Timeout) as e:
        alert(f"Lỗi kết nối: {str(e)}")
        return None
    except RequestException as e:
        alert(f"Lỗi khi tìm kiếm: {str(e)}")
        return None

    soup = BeautifulSoup(response.content, "html.parser")
    result_items = soup.find_all('div', class_='result-item')
    items = []

    for result_item in result_items:
        img_src = result_item.find('img')['src']
        href = result_item.find('a')['href']
        name = result_item.find('div', class_='title')
        if name:
            name = name.text.strip()
            name = re.sub(r'\s*\b(?:HD|SD)\b\s*', '', name, flags=re.IGNORECASE)
            name = name.strip()

        else:
            name = ""

        year = result_item.find('span', class_='year')
        if year:
            year = year.text.strip()
            name = name +" (%s)" % year
        else:
            name = name

        info = result_item.find('div', class_='contenido')
        if info:
            info = info.text.strip()
            info = re.sub(r'\s+', ' ', info)
            info = info.replace('thuvienhd.top', '')
            info = info.replace('https://', '')
            info = info.strip()
        else:
            info = ""

        max_desc_length = 2000
        if len(info) > max_desc_length:
            info = info[:max_desc_length] + "..."

        encoded_desc = urllib.parse.quote_plus(info.encode('utf-8'))


        full_path = f"{addon_url}browse&url={href}&desc={encoded_desc}"

        item = {
            "label": name,
            "is_playable": False,
            "path": full_path,
            "thumbnail": img_src,
            "icon": img_src,
            "label2": "",
            "info": {"plot": info},
            "art": {"fanart": img_src}
        }

        items.append(item)

    next_page = int(page) + 1
    next_page_url = "https://thuvienhd.top/page/%s?s=%s" % (next_page, query)

    try:

        response = session.head(next_page_url, verify=False, timeout=10)

        if response.status_code == 200:
            next_page_url = addon_url + "browse&url=" + next_page_url
            nextpage = {
                "label": '[COLOR yellow]Trang %s[/COLOR] ' % next_page,
                "is_playable": False,
                "path": next_page_url,
                "thumbnail": 'https://i.imgur.com/yCGoDHr.png',
                "icon": "https://i.imgur.com/yCGoDHr.png",
                "label2": "",
                "info": {"plot": "Trang tiếp TVHD"}
            }
            items.append(nextpage)
    except Exception as e:
        xbmc.log(f"[VietmediaF] Lỗi khi kiểm tra trang tiếp theo: {str(e)}", xbmc.LOGINFO)

    data = {"content_type": "episodes", "items": items}


    cache_utils.set_cache(cache_key, data)

    return data

def getlink(url, description=""):

    cache_key = hashlib.md5(url.encode()).hexdigest() + "_links"

    if cache_utils.check_cache(cache_key, 30):
        cache_data = cache_utils.get_cache(cache_key)
        if cache_data:

            return cache_data

    def getlink_(url):

        try:

            response = session.get(url, verify=False, timeout=30)
            response.raise_for_status()

            soup = BeautifulSoup(response.content, "html.parser")
            try:
                description = soup.find('div', class_='cnnn').text.strip()

                description = description.replace("thuvienhd.top", "")
                description = description.strip()
                description = description.replace("https://","")
            except:
                description = ''


            img_tag = soup.find("div", class_="poster").find("img")
            img_path = img_tag["src"]



            a_tag = soup.find("span", class_="box__download").find("a")
            href = a_tag["href"]



            response = session.get(href, verify=False, timeout=30)
            response.raise_for_status()

            soup = BeautifulSoup(response.content, "html.parser")
            link_tags = soup.select('table.post_table a[href*="fshare.vn"]')
            links = [link['href'] for link in link_tags]

            items = []
            total_links = len(links)

            for index, href in enumerate(links, 1):
                name, file_type, size_file = fshare.get_fshare_file_info(href)
                item = {}
                if "folder" in href:
                    playable = False
                else:
                    playable = True
                item["label"] = name
                item["is_playable"] = playable
                item["path"] = 'plugin://plugin.video.vietmediaF?action=browse&url=%s' % href
                item["thumbnail"] = img_path
                item["icon"] = img_path
                item["label2"] = ""
                item["info"] = {'plot': description, 'size': size_file}
                item["art"] = {'fanart':img_path }
                items.append(item)

            data = {"content_type": "movies", "items": ""}

            data.update({"items": items})
            return data

        except (ConnectionError, Timeout) as e:
            alert(f"Lỗi kết nối: {str(e)}")
            return None
        except RequestException as e:
            alert(f"Lỗi khi tải trang: {str(e)}")
            return None
        except Exception as e:
            alert(f"Lỗi không xác định: {str(e)}")
            return None

    data = getlink_(url)

    if data:
        cache_utils.set_cache(cache_key, data)

    return data
def listGenre(url):

    cache_key = hashlib.md5(url.encode()).hexdigest() + "_genre"

    if cache_utils.check_cache(cache_key, 30):
        cache_data = cache_utils.get_cache(cache_key)
        if cache_data:

            return cache_data

    def listGenre_(url):
        try:
            response = session.get(url, verify=False, timeout=30)
            response.raise_for_status()
            html_content = response.content
            soup = BeautifulSoup(html_content, "html.parser")
            articles = soup.find_all("article", class_="item movies")
            items = []
            for article in articles:
                img = article.find("img").get("src")
                fanart = img
                href = article.find("a").get("href") if article.find("a") else ""
                data = article.find('div', class_='data')

                year_elem = data.find('span') if data else None
                year = year_elem.text.strip() if year_elem else ''
                year_int = int(year) if year and year.isdigit() else 0

                title_elem = article.find("div", class_="title")
                name = title_elem.text.strip() if title_elem else ""


                imdb_elem = article.find("span", class_="imdb")
                imdb = imdb_elem.text.strip() if imdb_elem else ""

                imdb_rating = 0.0
                if imdb:
                    try:

                        imdb_match = re.search(r'([\d.]+)', imdb)
                        if imdb_match:
                            imdb_rating = float(imdb_match.group(1))
                    except:
                        imdb_rating = 0.0


                desc_elem = article.find("div", class_="texto")
                description = desc_elem.text.strip() if desc_elem else ""


                if imdb:
                    description = f"[COLOR yellow]IMDB: {imdb}[/COLOR]\n\n{description}"


                if year:
                    name = f"{name} ({year})"


                genre_div = article.find("div", class_="genres")
                if genre_div:
                    links = genre_div.find_all('a')
                    genre = '/'.join(link.text.strip() for link in links)
                else:
                    genre = "N/A"


                item = {}
                item["label"] = name
                item["is_playable"] = False
                encoded_description = urllib.parse.quote_plus(description)
                item["path"] = addon_url + "browse&url=" + href + "&desc=" + encoded_description
                item["thumbnail"] = img
                item["icon"] = img
                item["label2"] = name


                item["info"] = {
                    'title': name,
                    'plot': description,
                    'genre': genre,
                    'year': year_int,
                    'rating': imdb_rating,
                    'mediatype': 'movie'
                }


                item["art"] = {
                    "fanart": fanart,
                    "poster": img,
                    "thumb": img,
                    "icon": img
                }

                items.append(item)



            try:
                pagination = soup.find("div", class_="pagination")
                if pagination:
                    current_page_span = pagination.find("span", class_="current")
                    current_page = int(current_page_span.text.strip())
                    next_page = current_page + 1

                    if "page" in url:
                        match = re.search(r"(.*)\/page",url)
                        if match:
                            next_url = match.group(1)
                    else:
                        next_url = url

                    next_url = "%s/page/%s" % (next_url,next_page)
                    next_page_url = addon_url + "browse&url=vmf"+next_url


                    nextpage = {
                        "label": f'[COLOR yellow]Trang {next_page}[/COLOR]',
                        "is_playable": False,
                        "path": next_page_url,
                        "thumbnail": 'https://i.imgur.com/yCGoDHr.png',
                        "icon": "https://i.imgur.com/yCGoDHr.png",
                        "label2": "",
                        "info": {
                            'plot': 'Trang tiếp theo',
                            'mediatype': 'video'
                        },
                        "art": {
                            'thumb': 'https://i.imgur.com/yCGoDHr.png',
                            'icon': 'https://i.imgur.com/yCGoDHr.png',
                            'poster': 'https://i.imgur.com/yCGoDHr.png'
                        }
                    }
                    items.append(nextpage)
            except Exception as e:
                xbmc.log(f"[VietmediaF] Lỗi khi kiểm tra trang tiếp theo: {str(e)}", xbmc.LOGINFO)

            data = {"content_type": "movies", "items": ""}
            data.update({"items": items})
            return data

        except (ConnectionError, Timeout) as e:
            alert(f"Lỗi kết nối: {str(e)}")
            return None
        except RequestException as e:
            alert(f"Lỗi khi tải trang: {str(e)}")
            return None
        except Exception as e:
            alert(f"Lỗi không xác định: {str(e)}")
            return None

    data = listGenre_(url)


    if data:
        cache_utils.set_cache(cache_key, data)

    return data


def listMovie(url):

    def listMovie_(url):
        success = False
        for _ in range(3):
            try:
                response = requests.get(url, verify=False, timeout=30)
                success = True
                break
            except Exception as e:
                alert('Không lấy được nội dung từ web')
        soup = BeautifulSoup(response.content, "html.parser")
        divs = soup.find_all("article", {"id": lambda x: x and x.startswith("post-")})
        items = OrderedDict()
        lock = threading.Lock()

        def get_info(href):
            try:
                response = requests.get(href, verify=False, timeout=30)
                soup = BeautifulSoup(response.content, "html.parser")

                genre_div = soup.find("div", class_="sgeneros")
                if genre_div:
                    links = genre_div.find_all('a')
                    genre = '/'.join(link.text.strip() for link in links)
                else:
                    genre = "N/A"

                data_div = soup.find('div', class_='data')
                try:
                    name_vie = data_div.find('h1').text.strip()
                except AttributeError:
                    try:
                         name_vie = data_div.find('h3').text.strip()
                    except AttributeError:
                            name_vie = ''


                year = ""
                year_match = re.search(r'\((\d{4})\)', name_vie)
                if year_match:
                    year = year_match.group(1)

                    name_vie = re.sub(r'\s*\(\d{4}\)\s*', '', name_vie).strip()

                try:
                    name_eng = soup.find('h2', class_='title-en').text.strip()
                    name_eng = name_eng.replace("|", "-")
                    name = name_vie + " - " + name_eng
                except:
                    name = name_vie
                name = name.replace("|","-")


                imdb_rating = 0.0
                try:
                    imdb_elem = soup.find('b', id='repimdb')
                    if imdb_elem:

                        strong_tag = imdb_elem.find('strong')
                        if strong_tag:
                            imdb_text = strong_tag.text.strip()

                            try:
                                imdb_rating = float(imdb_text)
                            except:
                                imdb_rating = 0.0
                except Exception as e:
                    xbmc.log(f"[VietmediaF] Lỗi khi lấy điểm IMDB: {str(e)}", xbmc.LOGINFO)

                try:
                    description = soup.find('div', class_='cnnn').text.strip()
                    description = description.replace("thuvienhd.top", "")
                    description = description.strip()
                    description = description.replace("https://","")


                    if imdb_rating > 0:
                        description = f"[COLOR yellow]IMDB: {imdb_rating}/10[/COLOR]\n\n{description}"
                except:
                    description = ''

                return (name, description, genre, year, imdb_rating)
            except Exception as e:
                alert(f"get_info: {e}")
                return ('', '', '', '', 0.0)

        def process_div(div):
            try:
                img_tag = div.find('img')
                img = img_tag['src']



                data_div = div.find('div', class_='data')
                href = data_div.find('a')['href']


                name, description, genre, year, imdb_rating = get_info(href)

                name = name.strip()


                item = {}
                item["label"] = name
                item["is_playable"] = False
                item["path"] = addon_url + "browse&url=" + href
                item["thumbnail"] = img
                item["icon"] = img
                item["label2"] = name


                item["info"] = {
                    'title': name,
                    'plot': description,
                    'genre': genre,
                    'year': int(year) if year and year.isdigit() else 0,
                    'rating': imdb_rating,
                    'mediatype': 'movie'
                }


                item["art"] = {
                    "fanart": img,
                    "poster": img,
                    "thumb": img,
                    "icon": img
                }

                with lock:
                    items[div] = item
            except Exception as e:
                TextBoxes("Error processing div", e)

        class CustomThreadPoolExecutor(ThreadPoolExecutor):
            def __init__(self, max_workers):
                super().__init__(max_workers=max_workers)
                self._work_lock = threading.Lock()

            def submit(self, fn, *args, **kwargs):
                with self._work_lock:
                    future = super().submit(fn, *args, **kwargs)
                    future.add_done_callback(self._callback)
                    return future

            def _callback(self, future):
                try:
                    future.result()
                except Exception as e:
                    print(f"Error in thread: {e}")

        with CustomThreadPoolExecutor(max_workers=len(divs)) as executor:
            executor.map(process_div, divs)

        sorted_items = [items[div] for div in divs]

        try:
            pagination = soup.find("div", class_="pagination")
            if pagination:
                current_page_span = pagination.find("span", class_="current")
                current_page = int(current_page_span.text.strip())
                next_page = current_page + 1

                if "trending" in url:
                    next_url = "https://thuvienhd.top/trending/page/%s?get=movies" % next_page

                else:
                    if "page" in url:
                        match = re.search(r"(.*)\/page",url)
                        if match:
                            next_url = match.group(1)

                    else:
                        next_url = url

                    next_url = "%s/page/%s" % (next_url,next_page)
                next_page_url = addon_url + "browse&url=vmf"+next_url
                nextpage = {"label": '[COLOR yellow]Trang %s [/COLOR]' % str(next_page), "is_playable": False, "path": next_page_url, "thumbnail": 'https://i.imgur.com/yCGoDHr.png', "icon": "https://i.imgur.com/yCGoDHr.png", "label2": "", "info": {'plot': 'Trang tiếp'}}
                sorted_items.append(nextpage)
        except:pass
        data = {"content_type": "movies", "items": ""}
        data.update({"items": sorted_items})
        return(data)


    cache_filename = hashlib.md5(url.encode()).hexdigest() + '_cache.json'
    cache_path = os.path.join(CACHE_PATH, cache_filename)
    if cache_utils.check_cache(cache_path):

        with open(cache_path, 'r') as cache_file:
            cache_content = json.load(cache_file)
        return cache_content
    else:
        data = listMovie_(url)
        with open(cache_path, "w") as f:
            json.dump(data, f)
        return data
def receive(url):
    # Trích xuất URL từ tham số đầu vào nếu cần
    match = re.search(r"url=(.*)", url)
    if match:
        url = match.group(1)

    xbmc.log(f"[VietmediaF] TVHD receive URL: {url}", xbmc.LOGINFO)

    if "menu" in url:
        names = ['Tìm kiếm','Mới nhất','Xu hướng','Phim lẻ','Phim bộ','Phim lẻ thể loại','Phim Bộ theo quốc gia','Phim 18+','Phim H265','Phim TVB','Phim Thuyết Minh','Phim Lồng Tiếng']
        links = [addon_url+"browse&url=https://thuvienhd.top/timkiem",
                addon_url+"browse&url=https://thuvienhd.top/recent",
                addon_url+"browse&url=https://thuvienhd.top/trending?get=movies",
                addon_url+"browse&url=vmfhttps://thuvienhd.top/genre/phim-le",
                addon_url+"browse&url=vmfhttps://thuvienhd.top/genre/series",
                addon_url+"browse&url=https://thuvienhd.top/genre/theloai",
                addon_url+"browse&url=vmfhttps://thuvienhd.top/genre/quocgia",
                addon_url+"browse&url=vmfhttps://thuvienhd.top/genre/18",
                addon_url+"browse&url=vmfhttps://thuvienhd.top/genre/h265",
                addon_url+"browse&url=https://thuvienhd.top/genre/tvb",
                addon_url+"browse&url=vmfhttps://thuvienhd.top/genre/thuyet-minh-tieng-viet",
                addon_url+"browse&url=vmfhttps://thuvienhd.top/genre/long-tieng-tieng-viet"]
        items = []

        for name, link in zip(names,links):
            if "phim-le" in link:
                fanart = "https://thuvienhd.top/wp-content/themes/dooplay/images/banner_phimle.jpg"
            elif "genre/18" in link:
                fanart = "https://thuvienhd.top/wp-content/themes/dooplay/images/phim18.jpg"
            elif "genre/series" in link:
                fanart = "https://thuvienhd.top/wp-content/themes/dooplay/images/banner_series.jpg"
            else:fanart = "https://i.imgur.com/dGv6Non.jpg"
            item = {}
            item["label"] = name
            item["is_playable"] = False
            item["path"] = link
            item["thumbnail"] = "https://i.imgur.com/5dFJGyW.png"
            item["icon"] = "https://i.imgur.com/5dFJGyW.png"
            item["label2"] = ""
            item["info"] = {'plot': 'Các phim trên thuvienhd'}
            item["art"] = {'fanart': fanart}
            items += [item]
        data = {"content_type": "movies", "items": ""}
        data.update({"items": items})
        return data
    elif "trending" in url or "recent" in url or ("recent" in url and "vmf" in url):

        if "vmf" in url:
            url = url.replace("vmf","")
        match = re.search(r"url=(.*)",url)
        if match:
            url = match.group(1)
        try:data = listMovie(url)
        except Exception as e:
                alert(f"Error processing div: {e}")
        return data
    elif "theloai" in url:
        names = ['Hành Động', 'Võ Thuật','Viễn Tưởng', 'Kinh Dị', 'Hàn Quốc', '3D', '4K', 'Ấn Độ', 'Hài', 'Cao Bồi', 'Chiến Tranh', 'Chính Kịch', 'Cổ Trang', 'Gia Đình', 'Giáng Sinh', 'Hình Sự', 'Phim Hoạt Hình', 'Hongkong', 'Huyền Bí', 'Lãng Mạn', 'Lịch Sử', 'Nhạc Kịch', 'Phiêu Lưu', 'Phim', 'Phim Tài Liệu', 'Rùng Rợn', 'Tâm Lý', 'Thần Thoại', 'Thể Thao', 'Thiếu Nhi', 'Tiểu Sử', 'Tình Cảm', 'Trinh Thám', 'Trung Quốc']
        links = ['vmfhttps://thuvienhd.top/genre/action',
            'vmfhttps://thuvienhd.top/genre/vo-thuat-phim-2',
            'vmfhttps://thuvienhd.top/genre/sci-fi', 'vmfhttps://thuvienhd.top/genre/horror', 'vmfhttps://thuvienhd.top/genre/korean', 'vmfhttps://thuvienhd.top/genre/3d', 'vmfhttps://thuvienhd.top/genre/4k', 'vmfhttps://thuvienhd.top/genre/india', 'vmfhttps://thuvienhd.top/genre/comedy', 'vmfhttps://thuvienhd.top/genre/western', 'vmfhttps://thuvienhd.top/genre/war', 'vmfhttps://thuvienhd.top/genre/chinh-kich', 'vmfhttps://thuvienhd.top/genre/co-trang-phim', 'vmfhttps://thuvienhd.top/genre/gia-dinh', 'vmfhttps://thuvienhd.top/genre/giang-sinh', 'vmfhttps://thuvienhd.top/genre/crime', 'vmfhttps://thuvienhd.top/genre/animation', 'vmfhttps://thuvienhd.top/genre/hongkong', 'vmfhttps://thuvienhd.top/genre/mystery', 'vmfhttps://thuvienhd.top/genre/romance', 'vmfhttps://thuvienhd.top/genre/history', 'vmfhttps://thuvienhd.top/genre/nhac-kich', 'vmfhttps://thuvienhd.top/genre/adventure', 'vmfhttps://thuvienhd.top/genre/phim', 'vmfhttps://thuvienhd.top/genre/documentary', 'vmfhttps://thuvienhd.top/genre/thriller', 'vmfhttps://thuvienhd.top/genre/drama', 'vmfhttps://thuvienhd.top/genre/fantasy', 'vmfhttps://thuvienhd.top/genre/the-thao', 'vmfhttps://thuvienhd.top/genre/family', 'vmfhttps://thuvienhd.top/genre/tieu-su', 'vmfhttps://thuvienhd.top/genre/tinh-cam', 'vmfhttps://thuvienhd.top/genre/trinh-tham', 'vmfhttps://thuvienhd.top/genre/trung-quoc-series']
        items = []
        for name, link in zip(names,links):
            item = {}
            item["label"] = name
            item["is_playable"] = False
            item["path"] = addon_url + "browse&url="+link
            item["thumbnail"] = "https://i.imgur.com/5dFJGyW.png"
            item["icon"] = "https://i.imgur.com/5dFJGyW.png"
            item["label2"] = ""
            item["info"] = {'plot': ''}
            item["art"] = {'fanart': "https://i.imgur.com/dGv6Non.jpg"}
            items += [item]
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        return data
    elif "quocgia" in url:
        links =  ['vmfhttps://thuvienhd.top/genre/phim-bo-viet-nam',
        'vmfhttps://thuvienhd.top/genre/us-tv-series',
        'vmfhttps://thuvienhd.top/genre/korean-series',
        'vmfhttps://thuvienhd.top/genre/phim-bo-trung-quoc',
        'vmfhttps://thuvienhd.top/genre/hongkong-series',
        'vmfhttps://thuvienhd.top/genre/phi-bo-nigeria', 'vmfhttps://thuvienhd.top/genre/phim-bo-a-rap', 'vmfhttps://thuvienhd.top/genre/phim-bo-ai-cap', 'vmfhttps://thuvienhd.top/genre/phim-bo-ai-nhi-lan-ireland', 'vmfhttps://thuvienhd.top/genre/phim-bo-an-do', 'vmfhttps://thuvienhd.top/genre/phim-bo-anh', 'vmfhttps://thuvienhd.top/genre/phim-bo-ao', 'vmfhttps://thuvienhd.top/genre/phim-bo-argentina', 'vmfhttps://thuvienhd.top/genre/phim-bo-australia', 'vmfhttps://thuvienhd.top/genre/phim-bo-ba-lan', 'vmfhttps://thuvienhd.top/genre/phim-bo-bi', 'vmfhttps://thuvienhd.top/genre/phim-bo-bo-dao-nha', 'vmfhttps://thuvienhd.top/genre/phim-bo-brazil', 'vmfhttps://thuvienhd.top/genre/phim-bo-canada', 'vmfhttps://thuvienhd.top/genre/phim-bo-chile', 'vmfhttps://thuvienhd.top/genre/phim-bo-colombia', 'vmfhttps://thuvienhd.top/genre/phim-bo-dai-loan', 'vmfhttps://thuvienhd.top/genre/phim-bo-dan-mach', 'vmfhttps://thuvienhd.top/genre/phim-bo-duc', 'vmfhttps://thuvienhd.top/genre/phim-bo-ha-lan',  'vmfhttps://thuvienhd.top/genre/phim-bo-iceland', 'vmfhttps://thuvienhd.top/genre/phim-bo-ireland', 'vmfhttps://thuvienhd.top/genre/phim-bo-israel', 'vmfhttps://thuvienhd.top/genre/phim-bo-jordan', 'vmfhttps://thuvienhd.top/genre/phim-bo-mexico',  'vmfhttps://thuvienhd.top/genre/phim-bo-na-uy', 'vmfhttps://thuvienhd.top/genre/phim-bo-nam-phi', 'vmfhttps://thuvienhd.top/genre/phim-bo-new-zealand', 'vmfhttps://thuvienhd.top/genre/phim-bo-nga', 'vmfhttps://thuvienhd.top/genre/phim-bo-nhat-ban', 'vmfhttps://thuvienhd.top/genre/phim-bo-phan-lan', 'vmfhttps://thuvienhd.top/genre/phim-bo-phap', 'vmfhttps://thuvienhd.top/genre/phim-bo-philippines', 'vmfhttps://thuvienhd.top/genre/phim-bo-romania', 'vmfhttps://thuvienhd.top/genre/phim-bo-singapo', 'vmfhttps://thuvienhd.top/genre/phim-bo-tay-ban-nha', 'vmfhttps://thuvienhd.top/genre/phim-bo-thai-lan', 'vmfhttps://thuvienhd.top/genre/phim-bo-tho-nhi-ky', 'vmfhttps://thuvienhd.top/genre/phim-bo-thuy-dien',   'vmfhttps://thuvienhd.top/genre/phim-bo-y']
        names = ['Phim Bộ Việt Nam','Phim Bộ Mỹ','Phim Bộ Hàn','Phim Bộ Trung Quốc','Phim Bộ Hongkong','Phi Bộ Nigeria', 'Phim Bộ Ả Rập', 'Phim Bộ Ai Cập', 'Phim Bộ Ái Nhĩ Lan (Ireland', 'Phim Bộ Ấn Độ', 'Phim bộ Anh', 'Phim Bộ Áo', 'Phim Bộ Argentina', 'Phim Bộ Australia', 'Phim Bộ Ba Lan', 'Phim Bộ Bỉ', 'Phim Bộ Bồ Đào Nha', 'Phim Bộ Brazil', 'Phim Bộ Canada', 'Phim Bộ Chile', 'Phim Bộ Colombia', 'Phim Bộ Đài Loan', 'Phim Bộ Đan Mạch', 'Phim Bộ Đức', 'Phim Bộ Hà Lan','Phim Bộ Iceland', 'Phim Bộ Ireland', 'Phim Bộ Israel', 'Phim Bộ Jordan', 'Phim Bộ Mexico',  'Phim Bộ Na Uy', 'Phim Bộ Nam Phi', 'Phim Bộ New Zealand', 'Phim Bộ Nga', 'Phim Bộ Nhật Bản', 'Phim Bộ Phần Lan', 'Phim Bộ Pháp', 'Phim Bộ Philippines', 'Phim Bộ Romania', 'Phim Bộ Singapo', 'Phim Bộ Tây Ban Nha', 'Phim Bộ Thái Lan', 'Phim Bộ Thổ Nhĩ Kỳ', 'Phim Bộ Thụy Điển', 'Phim Bộ Ý']
        items = []
        for name, link in zip(names,links):
            item = {}
            item["label"] = name
            item["is_playable"] = False
            item["path"] = addon_url + "browse&url="+link
            item["thumbnail"] = "https://i.imgur.com/5dFJGyW.png"
            item["icon"] = "https://i.imgur.com/5dFJGyW.png"
            item["label2"] = ""
            item["info"] = {'plot': ''}
            item["art"] = {'fanart': "https://i.imgur.com/dGv6Non.jpg"}
            items += [item]
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        return data
    elif "timkiem" in url:
        keyboard = xbmc.Keyboard("", "Nhập tên phim")
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            query = keyboard.getText()
            query = urllib.parse.unquote(query)
            data = search("1",query)
            return data
        else:
            alert("Không có gì được nhập vào.")
            return
    elif "?s=" in url:

        current_page = re.search(r"\/page\/(\d+)",url).group(1)
        query = re.search(r"s=(.*)",url).group(1)
        data = search(current_page,query)
        return data
    elif "genre" in url:
        if "vmf" in url:
            url = url.replace("vmf","")

        data = listGenre(url)
        return data
    else:

        original_url = url
        description = ""


        if "&desc=" in url:
            parts = url.split("&desc=")
            url = parts[0]
            description = urllib.parse.unquote_plus(parts[1])


        if "vmf" in url:
            url = url.replace("vmf","")

        match = re.search(r"url=(.*)",url)
        if match:
            url = match.group(1)


        data = getlink(url, description)
        return data
