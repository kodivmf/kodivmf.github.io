import sys,re
import os, time, json, traceback
import remove_accents
import xbmcplugin, xbmcaddon, xbmcgui, xbmc, xbmcvfs
from resources.addon import alert, notify, TextBoxes, ADDON, ADDON_ID, ADDON_PROFILE, LOG, PROFILE
from config import VIETMEDIA_HOST
from resources import fshare
import urllib.parse


ADDON_NAME = ADDON.getAddonInfo("name")
PROFILE_PATH = xbmcvfs.translatePath(ADDON_PROFILE)
VIEWXXX = ADDON.getSetting('view_xxx')
VIEWMODE = ADDON.getSetting('view_mode')
HANDLE = int(sys.argv[1])
CACHE_TIMEOUT = 300

def debug(text):

    filename = os.path.join(PROFILE_PATH, 'list.dat')
    if not os.path.exists(filename):
        with open(filename, "w+", encoding="utf-8") as f:
            f.write(text)
    else:
        with open(filename, "wb") as f:
            f.write(text.encode("UTF-8"))


def check_lock(item_path):

    filename = os.path.join(PROFILE_PATH, 'lock_dir.dat')
    if not os.path.exists(filename):
        return False
    with open(filename, "r") as f:
        lines = f.readlines()
    return (item_path + "\n") in lines
def list_item_main(data):

    window_id = xbmc.getInfoLabel('System.CurrentWindowId')
    window_name = xbmc.getInfoLabel('System.CurrentWindow')
    xbmc.log(f"[VietmediaF] Loading list in Window ID: {window_id}, Window Name: {window_name}", xbmc.LOGINFO)


    if data is None:

        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if data.get("content_type") and len(data["content_type"]) > 0:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)
        xbmcplugin.setContent(HANDLE, data["content_type"])
    listitems = list(range(len(data["items"])))

    for i, item in enumerate(data["items"]):
        lock_url = item["path"].replace("plugin://%s" % ADDON_ID, VIETMEDIA_HOST)
        lock_url = re.sub('\?', '/?', lock_url)
        path = item["path"]
        label = item["label"]
        filterStr = ["xxx", "sex", "jav", "cap 3", "18+", "20+"]
        if check_lock(lock_url):label = "*" + label
        listItem = xbmcgui.ListItem(label=label, label2=item["label2"])
        if VIEWXXX == 'false':
            label_ = label.lower()
            if '18+' in label_ or 'xxx' in label_ or 'XXX' in label_ or 'cấp 3' in label or 'jav' in label_ or 'JAV' in label_ or '+' in label_ or 'sex' in label_ or 'SEX' in label_ or 'fuck' in label_ or '20+' in label_:

                listItem = xbmcgui.ListItem(label='[I]Nội dung cần thiết lập để xem[/I]',label2=item["label2"])
                path = 'plugin://plugin.video.vietmediaF?action=browse&node_id=75'

            else:

                listItem = xbmcgui.ListItem(label=label, label2=item["label2"])
        if VIEWXXX == 'true':
            listItem = xbmcgui.ListItem(label=label, label2=item["label2"])

        if item.get("info"):
            listItem.setInfo("video", item["info"])

        if item.get("art"):
            listItem.setArt(item["art"])

        listItem.setArt({'thumb': item["thumbnail"], 'icon': item["thumbnail"], 'poster': item["icon"]})

        menu_context = []
        title = item["label"]
        title = re.sub('\[.*?]', '', title)
        title = re.sub('\s', '-', title)
        title = re.sub('--', '-', title)
        title = re.sub('--', '-', title)
        title = re.sub('[\\\\/*?:"<>|]', "", title)
        title = remove_accents.remove_accents(title)
        if item.get("context_menu"):
            listItem.addContextMenuItems(item["context_menu"])
        elif "_phimle_" in path:
            command = 'RunPlugin(%s&d=select_source_phimle)' % item["path"]
            menu_context.append(('Thay đổi nguồn phim', command,))
        elif "_phimbo_" in path:
            command = 'RunPlugin(%s&d=select_source_phimbo)' % item["path"]
            menu_context.append(('Thay đổi nguồn phim', command,))
        elif "fshare.vn" in path:
            command = 'RunPlugin(%s&d=__addtofav__&file_name=%s)' % (item["path"], title)
            menu_context.append(('[COLOR yellow]Thêm vào Yêu Thích Fshare[/COLOR]', command,))
            command = 'RunPlugin(%s&d=__removeFromfav__&file_name=%s)' % (item["path"], title)
            menu_context.append(('[COLOR yellow]Xoá khỏi Yêu Thích Fshare[/COLOR]', command,))
            command = 'RunPlugin(%s&d=__qrlink__)' % item["path"]
            menu_context.append(('[COLOR yellow]Play on Mobile[/COLOR]', command,))
            if "file" in path:
                command = 'RunPlugin(%s&d=__download__)' % item["path"]
                menu_context.append(('[COLOR yellow]Download[/COLOR]', command,))
        command = 'RunPlugin(%s&d=__lock__)' % item["path"]
        menu_context.append(('Khoá mục này', command,))
        command = 'RunPlugin(%s&d=__unlock__)' % item["path"]
        menu_context.append(('Mở khoá mục này', command,))
        command = 'RunPlugin(%s&d=__settings__)' % item["path"]
        menu_context.append(('[COLOR yellow]Addon Setting[/COLOR]', command,))

        listItem.addContextMenuItems(menu_context)
        listItem.setProperty("isPlayable", item["is_playable"] and "true" or "false")
        if item.get("properties"):
            for k, v in item["properties"].items():

                if v is not None:
                    listItem.setProperty(k, str(v))
        listitems[i] = (path, listItem, not item["is_playable"])






    xbmcplugin.addDirectoryItems(HANDLE, listitems, totalItems=len(listitems))

    set_view_mode(data.get("content_type", "movies"))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)

def list_item_main_cache(data):

    window_id = xbmc.getInfoLabel('System.CurrentWindowId')
    window_name = xbmc.getInfoLabel('System.CurrentWindow')
    xbmc.log(f"[VietmediaF] Loading list_item_main_cache in Window ID: {window_id}, Window Name: {window_name}", xbmc.LOGINFO)




    if data is None:

        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    items = data["items"]
    for item in items:
        list_item = xbmcgui.ListItem(label=item["label"])
        list_item.setInfo('video', item["info"])

        list_item.setArt({'thumb': item["thumbnail"], 'icon': item["icon"]})
        list_item.setProperty('IsPlayable', 'true' if item["is_playable"] else 'false')
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=item["path"], listitem=list_item, isFolder=not item["is_playable"])


    set_view_mode(data.get("content_type", "movies"))
    xbmcplugin.endOfDirectory(HANDLE)

def list_item(data):

    window_id = xbmc.getInfoLabel('System.CurrentWindowId')
    window_name = xbmc.getInfoLabel('System.CurrentWindow')
    xbmc.log(f"[VietmediaF] Loading list_item in Window ID: {window_id}, Window Name: {window_name}", xbmc.LOGINFO)

    if data is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return


    if data.get("content_type"):
        xbmcplugin.setContent(HANDLE, data["content_type"])
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)

    listitems = []

    for item in data["items"]:

        label = item["label"]
        path = item["path"]


        list_item = xbmcgui.ListItem(label=label, label2=item.get("label2", ""))


        set_item_info(list_item, item)


        menu_context = []

        list_item.addContextMenuItems(menu_context)

        listitems.append((path, list_item, not item["is_playable"]))

    xbmcplugin.addDirectoryItems(HANDLE, listitems, totalItems=len(listitems))

    set_view_mode(data.get("content_type", "movies"))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
def list_item_watched_history(data):

    window_id = xbmc.getInfoLabel('System.CurrentWindowId')
    window_name = xbmc.getInfoLabel('System.CurrentWindow')
    xbmc.log(f"[VietmediaF] Loading list_item_watched_history in Window ID: {window_id}, Window Name: {window_name}", xbmc.LOGINFO)

    debug(str(data))

    if data is None:

        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if data.get("content_type") and len(data["content_type"]) > 0:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)
        xbmcplugin.setContent(HANDLE, data["content_type"])

    listitems = list(range(len(data["items"])))

    for i, item in enumerate(data["items"]):
        path = item["path"]
        label = item["label"]


        listItem = xbmcgui.ListItem(label=label, label2=item.get("label2", ""))


        if item.get("info"):
            listItem.setInfo("video", item["info"])


        listItem.setArt({'thumb': item.get("thumbnail", ""), 'icon': item.get("icon", "")})


        menu_context = []

        command = 'RunPlugin(%s&d=__removeAllWatchedHistory__)' % (path)
        menu_context.append(('[COLOR yellow]Xoá lịch sử xem phim[/COLOR]', command,))

        if "fshare" in path:
            command = 'RunPlugin(%s&d=__qrlink__)' % path
            menu_context.append(('[COLOR yellow]QR Link[/COLOR]', command,))

        listItem.addContextMenuItems(menu_context)


        listItem.setProperty("isPlayable", item["is_playable"] and "true" or "false")

        listitems[i] = (path, listItem, not item["is_playable"])

    xbmcplugin.addDirectoryItems(HANDLE, listitems, totalItems=len(listitems))

    set_view_mode(data.get("content_type", "movies"))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)
def list_item_search_history(data):

    window_id = xbmc.getInfoLabel('System.CurrentWindowId')
    window_name = xbmc.getInfoLabel('System.CurrentWindow')
    xbmc.log(f"[VietmediaF] Loading list_item_search_history in Window ID: {window_id}, Window Name: {window_name}", xbmc.LOGINFO)


    if data is None:

        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if data.get("content_type") and len(data["content_type"]) > 0:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)
        xbmcplugin.setContent(HANDLE, data["content_type"])

    listitems = list(range(len(data["items"])))

    for i, item in enumerate(data["items"]):
        lock_url = item["path"]
        lock_url = re.sub('\?', '/?', lock_url)
        path = item["path"]
        label = item["label"]

        if "@" in label:label = label.replace("@", "")

        if check_lock(lock_url):
            label = "*" + label


        label2 = item["label2"] if "label2" in item else ""
        if item.get("info") and "size" in item["info"]:

            size = item["info"]["size"]
            if isinstance(size, (int, float)):
                if size > 1073741824:
                    size_str = "{:.2f} GB".format(size / 1073741824)
                elif size > 1048576:
                    size_str = "{:.2f} MB".format(size / 1048576)
                elif size > 1024:
                    size_str = "{:.2f} KB".format(size / 1024)
                else:
                    size_str = "{} bytes".format(size)


                if label2:
                    label2 = label2 + " - " + size_str
                else:
                    label2 = size_str

        listItem = xbmcgui.ListItem(

            label=label, label2=label2)
        if item.get("info"):

            info_tag = listItem.getVideoInfoTag()


            if "plot" in item["info"]:
                info_tag.setPlot(item["info"]["plot"])


            if "title" in item["info"]:
                info_tag.setTitle(item["info"]["title"])
            if "year" in item["info"]:
                info_tag.setYear(int(item["info"]["year"]) if str(item["info"]["year"]).isdigit() else 0)
            if "genre" in item["info"]:
                info_tag.setGenres([item["info"]["genre"]])
            if "director" in item["info"]:
                info_tag.setDirectors([item["info"]["director"]])
            if "rating" in item["info"]:
                info_tag.setRating(float(item["info"]["rating"]) if isinstance(item["info"]["rating"], (int, float, str)) else 0.0)
            if "duration" in item["info"]:
                info_tag.setDuration(int(item["info"]["duration"]) if str(item["info"]["duration"]).isdigit() else 0)
            if "mediatype" in item["info"]:
                info_tag.setMediaType(item["info"]["mediatype"])
        if item.get("stream_info"):
            for type_, values in item["stream_info"].items():
                listItem.addStreamInfo(type_, values)
        if item.get("art"):
            listItem.setArt(item["art"])

        listItem.setArt({'thumb': item["thumbnail"], 'icon': item["thumbnail"], 'poster': item["icon"]})
        listItem.setProperty("isPlayable", item["is_playable"] and "true" or "false")
        if item.get("properties"):
            for k, v in item["properties"].items():
                listItem.setProperty(k, v)
        listitems[i] = (path, listItem, not item["is_playable"])

    xbmcplugin.addDirectoryItems(HANDLE, listitems, totalItems=len(listitems))

    set_view_mode(data.get("content_type", "movies"))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)

def set_item_info(list_item, item_data):
    """
    Hàm tổng quát để thiết lập tất cả thông tin cho ListItem
    Args:
        list_item: xbmcgui.ListItem object
        item_data: dict chứa thông tin item
    """

    info_tag = list_item.getVideoInfoTag()


    info = item_data.get("info", {})


    if "title" in info:
        info_tag.setTitle(info["title"])
    if "plot" in info:
        info_tag.setPlot(info["plot"])


    if "year" in info:
        try:
            info_tag.setYear(int(info["year"]))
        except (ValueError, TypeError):
            pass

    if "rating" in info:
        try:
            info_tag.setRating(float(info["rating"]))
        except (ValueError, TypeError):
            pass

    if "duration" in info:
        try:
            info_tag.setDuration(int(info["duration"]))
        except (ValueError, TypeError):
            pass


    if "genre" in info:
        genres = info["genre"].split(",") if isinstance(info["genre"], str) else [info["genre"]]
        info_tag.setGenres(genres)


    if "studio" in info:
        info_tag.setStudios([info["studio"]])

    if "director" in info:
        directors = info["director"].split(",") if isinstance(info["director"], str) else [info["director"]]
        info_tag.setDirectors(directors)

    if "cast" in info:
        cast = info["cast"] if isinstance(info["cast"], list) else [info["cast"]]
        info_tag.setCast(cast)

    if "country" in info:
        countries = info["country"].split(",") if isinstance(info["country"], str) else [info["country"]]
        info_tag.setCountries(countries)

    if "mpaa" in info:
        info_tag.setMpaa(info["mpaa"])


    art = {
        'thumb': item_data.get("thumbnail", ""),
        'icon': item_data.get("icon", ""),
        'poster': item_data.get("art", {}).get("poster", ""),
        'fanart': item_data.get("art", {}).get("fanart", ""),
        'clearart': item_data.get("art", {}).get("clearart", "")
    }
    list_item.setArt(art)


    if "stream_info" in item_data:
        for stream_type, values in item_data["stream_info"].items():
            list_item.addStreamInfo(stream_type, values)


    if "properties" in item_data:
        for key, value in item_data["properties"].items():
            list_item.setProperty(key, str(value))

def get_skin_view_modes():
    """Get view modes based on current skin"""
    current_skin = xbmc.getSkinDir()
    xbmc.log(f"[VietmediaF] Current skin: {current_skin}", xbmc.LOGINFO)

    view_modes = {
        "skin.arctic.zephyr.mod": {
            "list": 50,
            "poster": 51,
            "shift": 53,
            "info": 54,
            "wide": 55,
            "wall": 500,
            "banner": 501,
            "fanart": 502
        },

        "skin.confluence": {
            "list": 50,
            "poster": 500,
            "fanart": 504
        },

        "skin.estuary": {
            "poster": 50,
            "list": 51,
            "shift": 53,
            "wide": 54,
            "wall": 55
        }

    }


    skin_modes = view_modes.get(current_skin, view_modes["skin.arctic.zephyr.mod"])
    xbmc.log(f"[VietmediaF] View modes for skin: {skin_modes}", xbmc.LOGINFO)
    return skin_modes

def set_view_mode(content_type="movies"):
    """Set default view mode for different content types"""
    try:

        window_id = xbmc.getInfoLabel('System.CurrentWindowId')
        window_name = xbmc.getInfoLabel('System.CurrentWindow')
        xbmc.log(f"[VietmediaF] Attempting set_view_mode for content_type: '{content_type}' in Window ID: {window_id}, Name: {window_name}", xbmc.LOGINFO)


        xbmc.sleep(200)


        current_skin = xbmc.getSkinDir()
        view_mode = 50


        if current_skin == "skin.arctic.zephyr.mod":
            xbmc.log(f"[VietmediaF] Detected skin: {current_skin}", xbmc.LOGINFO)


            if VIEWMODE != "true":
                xbmc.log("[VietmediaF] View mode setting is disabled for Arctic Zephyr MOD. Skipping view mode setup.", xbmc.LOGINFO)
                return

            view_modes = {
                "netflix": 521, "biglist": 52, "bigposter": 53, "wide": 54,
                "posterwall": 55, "mediainfo": 56, "extrainfo": 57,
                "cards": 58, "bannerwall": 59, "list": 50
            }

            selected_view = ADDON.getSetting("view_mode_type").lower()
            default_view_id = view_modes.get(selected_view, view_modes["biglist"])
            xbmc.log(f"[VietmediaF] User preferred view (setting: {selected_view}): ID {default_view_id}", xbmc.LOGINFO)

            content_views = {
                "movies": default_view_id,
                "tvshows": default_view_id,
                "seasons": view_modes["biglist"],
                "episodes": view_modes["biglist"],
                "files": view_modes["biglist"]
            }

            current_url = xbmc.getInfoLabel('Container.FolderPath')
            xbmc.log(f"[VietmediaF] Current folder path: {current_url}", xbmc.LOGINFO)

            # Kiểm tra các trường hợp URL Fshare folder
            is_fshare_folder = (
                'fshare.vn/folder/' in current_url or
                'action=browse&url=https%3a%2f%2fwww.fshare.vn%2ffolder%2f' in current_url or
                'action=browse&amp;url=https%3a%2f%2fwww.fshare.vn%2ffolder%2f' in current_url or
                re.search(r'thuviencine\.com/phim-.*-fshare/?$', current_url)
            )

            if is_fshare_folder:
                view_mode = view_modes["list"]
                xbmc.log(f"[VietmediaF] Fshare folder detected. Using list view ({view_mode}).", xbmc.LOGINFO)
            else:
                view_mode = content_views.get(content_type, default_view_id)
                xbmc.log(f"[VietmediaF] Using view ID {view_mode} for content '{content_type}'.", xbmc.LOGINFO)


        elif current_skin == "skin.estuary":
            xbmc.log(f"[VietmediaF] Detected skin: {current_skin}", xbmc.LOGINFO)
            view_modes = {
                "list": 50,
                "poster": 50,
                "wide": 54,
                "posterwall": 55,
                "mediainfo": 53,
                "widelist": 56
            }


            if content_type == "movies":
                view_mode = view_modes["mediainfo"]
            elif content_type == "tvshows":
                view_mode = view_modes["posterwall"]
            elif content_type == "seasons":
                view_mode = view_modes["poster"]
            elif content_type == "episodes":
                view_mode = view_modes["wide"]
            elif content_type == "files":
                view_mode = view_modes["widelist"]
            else:
                view_mode = view_modes["list"]

            xbmc.log(f"[VietmediaF] Estuary: Using view ID {view_mode} for content '{content_type}'.", xbmc.LOGINFO)


        else:
            xbmc.log(f"[VietmediaF] Detected skin: {current_skin} (Using default logic)", xbmc.LOGINFO)
            view_modes = {
                "list": 50,
                "poster": 500,
                "wide": 51
            }

            if content_type in ["files", "episodes"]:
                view_mode = view_modes["list"]
            elif content_type in ["movies", "tvshows", "seasons"]:
                view_mode = view_modes.get("poster", view_modes["list"])
            else:
                view_mode = view_modes["list"]

            xbmc.log(f"[VietmediaF] Using default skin logic. Setting view ID {view_mode} for content '{content_type}'.", xbmc.LOGINFO)


        if view_mode is not None:
            command = f'Container.SetViewMode({view_mode})'
            xbmc.log(f"[VietmediaF] Executing command: {command}", xbmc.LOGINFO)
            xbmc.executebuiltin(command)
        else:
            xbmc.log(f"[VietmediaF] Could not determine a valid view_mode ID for content '{content_type}' on skin '{current_skin}'. Skipping SetViewMode.", xbmc.LOGWARNING)

    except Exception as e:
        xbmc.log(f"[VietmediaF] FATAL ERROR in set_view_mode: {e}", xbmc.LOGERROR)
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)