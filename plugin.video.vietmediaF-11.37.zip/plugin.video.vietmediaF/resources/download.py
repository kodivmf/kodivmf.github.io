import requests
import xbmcgui, xbmc, xbmcvfs
import time
import os, sys
import threading
import re

from resources.addon import alert, notify, TextBoxes, ADDON, ADDON_ID, ADDON_PROFILE, LOG, PROFILE
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
import getlink

def download_file(url, path):
    response = requests.head(url)
    size = int(response.headers.get("Content-Length", 0))
    file_name = url.split('/')[-1]
    file_path = os.path.join(path, file_name)
    
    if xbmcvfs.exists(file_path):
        dialog = xbmcgui.Dialog()
        overwrite = dialog.yesno("File Exists", "Bạn có muốn xoá đè file cũ không?")
        if not overwrite:
            return False
    
    def format_time(seconds):
        if seconds < 60:
            return f"{int(seconds)} giây"
        elif seconds < 3600:
            return f"{int(seconds/60)} phút {int(seconds%60)} giây"
        else:
            return f"{int(seconds/3600)} giờ {int((seconds%3600)/60)} phút"
    
    def download_thread():
        
        progress_dialog.create(f"{file_name}", "Chuẩn bị tải xuống...")
        
        start_time = time.time()
        downloaded = 0
        
        try:
            with requests.get(url, stream=True) as r:
                r.raise_for_status()
                with open(file_path, "wb") as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        if progress_dialog.iscanceled():
                            
                            progress_dialog.close()
                            
                            
                            if os.path.exists(file_path):
                                try:
                                    os.remove(file_path)
                                    notify("Đã hủy", "Đã hủy và xóa file tải xuống thành công")
                                except Exception as e:
                                    notify("Lỗi", f"Không thể xóa file: {str(e)}")
                            else:
                                notify("Đã hủy", "Đã hủy tải xuống thành công")
                            
                            return
                            
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            
                            
                            current_time = time.time()
                            elapsed_time = current_time - start_time
                            progress = int(downloaded / size * 100) if size > 0 else 0
                            speed = downloaded / elapsed_time if elapsed_time > 0 else 0
                            time_left = (size - downloaded) / speed if speed > 0 else 0
                            
                            
                            speed_text = f"Tốc độ: {speed/1024/1024:.2f} MB/s"
                            time_text = f"Thời gian còn lại: {format_time(time_left)}"
                            
                            progress_dialog.update(
                                progress, 
                                f"Đang tải: {progress}% - size: {size/1024/1024:.2f} MB\n{speed_text} {time_text}"
                            )
            
            progress_dialog.close()
            notify( 'Tải xuống đã hoàn thành')
            
            if xbmcgui.Dialog().yesno("Phát file?", "Bạn có muốn phát video này ngay bây giờ không?"):
                xbmc.Player().play(file_path)
                
        except Exception as e:
            progress_dialog.close()
            alert(f'Lỗi khi tải xuống: {str(e)}')
            LOG.error(f"Lỗi khi tải xuống: {str(e)}")
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                    
                except:
                    pass
    
    
    download_thread = threading.Thread(target=download_thread)
    download_thread.start()

    return True

def downloadfile(url):
    download_path = ADDON.getSetting("download_path")
    if not download_path:
        dialog = xbmcgui.Dialog()
        choice = dialog.yesno('Thiết lập đường dẫn', 'Đường dẫn lưu trữ chưa được thiết lập. Bạn có muốn thiết lập ngay bây giờ?')
        if choice:
            download_path = dialog.browse(3, 'Chọn đường dẫn lưu trữ', 'files')
            if not download_path:
                return
            ADDON.setSetting("download_path", download_path)
        else:
            return
    progress_dialog = xbmcgui.DialogProgressBG()
    progress_dialog.create('Đang tải xuống', 'Đang lấy link tải xuống...')
    progress_dialog.update(10)
    progress_dialog.close()
    match = re.search(r"url=([^&]+)", url)
    if match:
        url = match.group(1)
    else:
        alert("Không lấy được url để download")
        return
    
    if "fshare.vn" in url:
        token, session_id = fshare.check_session()
        url = fshare.get_download_link(token, session_id, url)
        
    if "4share.vn" in url:
        url = getlink.get_4share(url)
        


    download_file(url, download_path)
    