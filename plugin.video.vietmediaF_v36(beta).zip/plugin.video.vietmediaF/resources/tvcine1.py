import time, random
from bs4 import BeautifulSoup
import hashlib
import re, json, os
import urllib.parse
import sys
import requests
from requests.exceptions import ConnectionError, Timeout, RequestException
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from resources import fshare, cache_utils
from resources.addon import alert, notify, TextBoxes, getadv, ADDON, ADDON_ID, addon_url
from resources.lib.constants import CACHE_PATH, USER_AGENT
import xbmcgui, xbmc, xbmcvfs, xbmcplugin
from datetime import timedelta
from resources.history_utils import tvcine_history
from resources.utils import save_fshare_metadata, get_cached_metadata, clear_specific_cache
from resources.search import timfshare

def create_session():
    session = requests.Session()

    retry_strategy = Retry(
        total=3,
        backoff_factor=0.5,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST"]
    )

    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)

    session.headers.update({
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1"
    })

    return session

session = create_session()

def getlink(url, img, description, english_name):
    def getlink_tvcn(url, img, description):
        start = time.time()
        dialog = xbmcgui.DialogProgress()
        dialog.create('Đang lấy dữ liệu', 'Vui lòng đợi...')

        try:

            response = session.get(url, verify=False, timeout=10)
            response.raise_for_status()

            if time.time() - start > 8:
                dialog.close()
                notify("Trang web phản hồi lâu, vui lòng thử lại sau!")
                return None

            dialog.update(30, 'Phân tích dữ liệu...')

            soup = BeautifulSoup(response.content, "html.parser")
            items = []
            links = soup.find_all('a', href=lambda href: href and 'fshare.vn' in href)
            total_links = len(links)

            dialog.update(50, f'Tìm thấy {total_links} link Fshare')
        except (ConnectionError, Timeout) as e:
            dialog.close()
            notify(f"Lỗi kết nối: {str(e)}")
            return None
        except RequestException as e:
            dialog.close()
            notify(f"Lỗi khi tải trang: {str(e)}")
            return None
        for i, link in enumerate(links):
            link = link.get('href')
            name,file_type,size_file = fshare.get_fshare_file_info(link)

            save_fshare_metadata(link, img, description)

            item={}
            if "folder" in link:
                playable = False
            else:
                playable = True

            item["label"] = name
            item["is_playable"] = playable
            item["path"] = 'plugin://plugin.video.vietmediaF?action=browse&url=%s' % link
            item["thumbnail"] = img
            item["icon"] = img
            item["label2"] = ""
            item["info"] = {'plot': description,'size':size_file}
            items += [item]
            progress = int((i + 1) / total_links * 100)
            dialog.update(progress, 'Đang lấy dữ liệu')
        dialog.close()
        data = {"content_type": "movies", "items": ""}
        data.update({"items": items})
        return data

    cache_key = hashlib.md5(url.encode()).hexdigest() + "_links"


    dialog = xbmcgui.DialogProgress()
    dialog.create('Đang lấy dữ liệu', 'Kiểm tra cache...')

    if cache_utils.check_cache(cache_key):
        dialog.update(30, 'Lấy dữ liệu từ cache...')
        cache_content = cache_utils.get_cache(cache_key)
        if cache_content:
            dialog.update(100, 'Đã lấy dữ liệu từ cache')
            xbmc.sleep(500)
            dialog.close()

            return cache_content

    dialog.update(10, 'Tải dữ liệu mới...')

    data = getlink_tvcn(url, img, description)

    if data:
        dialog.update(90, 'Lưu dữ liệu vào cache...')
        cache_utils.set_cache(cache_key, data)
        dialog.update(100, 'Hoàn tất')
        xbmc.sleep(500)

    try:
        data_timfshare = timfshare(english_name)

        if data_timfshare and "items" in data_timfshare:

            year = None
            year_match = re.search(r'\((\d{4})\)\s*$', english_name)
            if year_match:
                year = year_match.group(1)

                english_name = re.sub(r'\s*\(\d{4}\)\s*$', '', english_name).strip()


            search_terms = set(word.lower() for word in re.findall(r'\w+', english_name))

            filtered_items = []
            for item in data_timfshare["items"]:
                item_name = item["label"]

                item_terms = set(word.lower() for word in re.findall(r'\w+', item_name))


                year_match = True if not year else str(year) in item_name


                if search_terms.issubset(item_terms) and year_match:
                    item["thumbnail"] = img
                    item["icon"] = img
                    if "info" in item:
                        item["info"]["plot"] = description
                    else:
                        item["info"] = {"plot": description}
                    item["art"] = {
                        "fanart": img,
                        "icon": img,
                        "thumb": img,
                        "poster": img
                    }
                    filtered_items.append(item)


            data_timfshare["items"] = filtered_items


            if data and data_timfshare["items"]:
                data["items"] += data_timfshare["items"]

    except Exception as e:
        xbmc.log(f"[VietmediaF] Lỗi khi xử lý data_timfshare: {str(e)}", xbmc.LOGERROR)


    return data


def listMovie(url):
    def getlist(url):
        try:
            response = session.get(url, verify=False, timeout=30)
            response.raise_for_status()

            # Parse HTML content
            soup = BeautifulSoup(response.content, "html.parser")
            # Tìm tất cả div có id bắt đầu bằng "post-"
            divs = soup.find_all("div", {"id": lambda x: x and x.startswith("post-")})

            items = []
            t = len(divs)
            dialog = xbmcgui.DialogProgress()
            dialog.create('Đang lấy dữ liệu', 'Xin chờ...')

            for i, div in enumerate(divs):
                try:
                    # Lấy thông tin cơ bản
                    link = div.find("a")["href"]
                    img = div.find("img", class_="lazy")
                    if img:
                        img = img.get("data-src")

                    vietsub = div.find("span", class_=lambda value: value and value.startswith("item-quality"))
                    vietsub = vietsub.text.strip() if vietsub else "No sub"

                    # Parse trang chi tiết
                    detail_response = session.get(link, verify=False, timeout=30)
                    detail_soup = BeautifulSoup(detail_response.content, "html.parser")
                    item = parse_movie_info(detail_soup, img, vietsub, link)
                    items.append(item)

                    progress = int(i * 100 / t)
                    dialog.update(progress, f'Đang xử lý {i+1}/{t} phim...')

                except Exception as e:
                    xbmc.log(f"[VietmediaF] Lỗi khi parse phim: {str(e)}", xbmc.LOGERROR)
                    continue

            # Xử lý next page
            if "page" in url:
                next_page = re.search(r"/(\d+)/$", url).group(1)
                next_page = int(next_page) + 1
                base_url = re.search(r"(.*\/)page", url).group(1)
            else:
                next_page = "2"
                base_url = url

            next_page_url = base_url + "page/%s/" % next_page

            try:
                response = session.head(next_page_url, verify=False, timeout=10)
                if response.status_code == 200:
                    next_page_url = addon_url + "browse&url=vmf" + next_page_url
                    nextpage = {
                        "label": '[COLOR yellow]Trang %s[/COLOR] ' % next_page,
                        "is_playable": False,
                        "path": next_page_url,
                        "thumbnail": 'https://i.imgur.com/yCGoDHr.png',
                        "icon": "https://i.imgur.com/yCGoDHr.png",
                        "label2": "",
                        "info": {'plot': 'Trang tiếp TVCN'}
                    }
                    items.append(nextpage)
            except Exception as e:
                xbmc.log(f"[VietmediaF] Lỗi khi kiểm tra trang tiếp theo: {str(e)}", xbmc.LOGINFO)

            dialog.close()
            data = {"content_type": "movies", "items": items}
            return data

        except ConnectionError:
            alert('Không kết nối được đến web')
            return None
        except Timeout:
            alert('Yêu cầu đã vượt quá thời gian chờ')
            return None
        except RequestException as e:
            alert(f'Có lỗi xảy ra: {str(e)}')
            return None

    # Xử lý cache
    cache_key = hashlib.md5(url.encode()).hexdigest() + "_movie_list"
    dialog = xbmcgui.DialogProgress()
    dialog.create('Đang lấy dữ liệu', 'Kiểm tra cache...')

    if cache_utils.check_cache(cache_key):
        dialog.update(30, 'Lấy dữ liệu từ cache...')
        cache_content = cache_utils.get_cache(cache_key)
        if cache_content:
            dialog.update(100, 'Đã lấy dữ liệu từ cache')
            xbmc.sleep(500)
            dialog.close()
            return cache_content

    dialog.update(10, 'Tải dữ liệu mới...')
    data = getlist(url)

    if data:
        dialog.update(90, 'Lưu dữ liệu vào cache...')
        cache_utils.set_cache(cache_key, data)
        dialog.update(100, 'Hoàn tất')
        xbmc.sleep(500)

    dialog.close()
    return data

def receive(url):
    if "menu" in url:
        names = ["Tìm kiếm","Phim Lẻ","Phim Bộ","Xu hướng","Thể loại","Quốc gia","Chất lượng"]
        links = ["plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/timkiem/",
                "plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/movies/",
                "plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/tv-series/",
                "plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/top/",
                "plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/theloai",
                "plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/quocgia","plugin://plugin.video.vietmediaF?action=browse&url=https://thuviencine.com/chatluong"]
        items = []

        for name, link in zip(names,links):
            item = {}
            item["label"] = name
            item["is_playable"] = False
            item["path"] = link
            item["thumbnail"] = "https://i.imgur.com/GXyTFfi.png"
            item["icon"] = "https://i.imgur.com/GXyTFfi.png"
            item["label2"] = ""
            item["info"] = {'plot': name}
            item["art"] = {'fanart': "https://i.imgur.com/LkeOoN3.jpg"}
            items += [item]
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        return data
    elif "tv-series" in url or "/top/" in url or "/movies/" in url or "vmf" in url:
        if "vmf" in url:
            url = url.replace("vmf","")
        match = re.search(r"url=(.*)",url)
        if match:
            url = match.group(1)
        data = listMovie(url)
        return data
    elif "theloai" in url:
        links = ['vmfhttps://thuviencine.com/adventure/', 'vmfhttps://thuviencine.com/chuong-trinh-truyen-hinh/', 'vmfhttps://thuviencine.com/kids/', 'vmfhttps://thuviencine.com/phim-bi-an/', 'vmfhttps://thuviencine.com/phim-chien-tranh/', 'vmfhttps://thuviencine.com/phim-chinh-kich/', 'vmfhttps://thuviencine.com/phim-gay-can/', 'vmfhttps://thuviencine.com/phim-gia-dinh/', 'vmfhttps://thuviencine.com/phim-gia-tuong/', 'vmfhttps://thuviencine.com/phim-hai/', 'vmfhttps://thuviencine.com/phim-hanh-dong/', 'vmfhttps://thuviencine.com/phim-hinh-su/', 'vmfhttps://thuviencine.com/phim-hoat-hinh/', 'vmfhttps://thuviencine.com/phim-khoa-hoc-vien-tuong/', 'vmfhttps://thuviencine.com/phim-kinh-di/', 'vmfhttps://thuviencine.com/phim-lang-man/', 'vmfhttps://thuviencine.com/phim-lich-su/', 'vmfhttps://thuviencine.com/phim-mien-tay/', 'vmfhttps://thuviencine.com/phim-nhac/', 'vmfhttps://thuviencine.com/phim-phieu-luu/', 'vmfhttps://thuviencine.com/phim-tai-lieu/', 'vmfhttps://thuviencine.com/reality/', 'vmfhttps://thuviencine.com/science-fiction/', 'vmfhttps://thuviencine.com/soap/', 'vmfhttps://thuviencine.com/war-politics/']
        names = ['Adventure', 'Chương Trình Truyền Hình', 'Kids', 'Phim Bí Ẩn', 'Phim Chiến Tranh', 'Phim Chính Kịch', 'Phim Gây Cấn', 'Phim Gia Đình', 'Phim Giả Tượng', 'Phim Hài', 'Phim Hành Động', 'Phim Hình Sự', 'Phim Hoạt Hình', 'Phim Khoa Học Viễn Tưởng', 'Phim Kinh Dị', 'Phim Lãng Mạn', 'Phim Lịch Sử', 'Phim Miền Tây', 'Phim Nhạc', 'Phim Phiêu Lưu', 'Phim Tài Liệu', 'Reality', 'Science Fiction', 'Soap', 'War & Politics']
        items = []
        for name, link in zip(names,links):
            item = {}
            item["label"] = name
            item["is_playable"] = False
            item["path"] = addon_url + "browse&url="+link
            item["thumbnail"] = ""
            item["icon"] = ""
            item["label2"] = ""
            item["info"] = {'plot': name}
            item["art"] = {'fanart': "https://i.imgur.com/LkeOoN3.jpg"}
            items += [item]
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        return data
    elif "quocgia" in url:
        country_urls = {
            'Việt Nam': 'vmfhttps://thuviencine.com/country/vietnam/',
            'Anh': 'vmfhttps://thuviencine.com/country/united-kingdom/',
            'Argentina': 'vmfhttps://thuviencine.com/country/argentina/',
            'Australia': 'vmfhttps://thuviencine.com/country/australia/',
            'Austria': 'vmfhttps://thuviencine.com/country/austria/',
            'Belgium': 'vmfhttps://thuviencine.com/country/belgium/',
            'Bosnia and Herzegovina': 'vmfhttps://thuviencine.com/country/bosnia-and-herzegovina/',
            'Brazil': 'vmfhttps://thuviencine.com/country/brazil/',
            'Cambodia': 'vmfhttps://thuviencine.com/country/cambodia/',
            'Canada': 'vmfhttps://thuviencine.com/country/canada/',
            'Chile': 'vmfhttps://thuviencine.com/country/chile/',
            'China': 'vmfhttps://thuviencine.com/country/china/',
            'Colombia': 'vmfhttps://thuviencine.com/country/colombia/',
            'Czech Republic': 'vmfhttps://thuviencine.com/country/czech-republic/',
            'Denmark': 'vmfhttps://thuviencine.com/country/denmark/',
            'Dominican Republic': 'vmfhttps://thuviencine.com/country/dominican-republic/',
            'Estonia': 'vmfhttps://thuviencine.com/country/estonia/',
            'Finland': 'vmfhttps://thuviencine.com/country/finland/',
            'France': 'vmfhttps://thuviencine.com/country/france/',
            'Germany': 'vmfhttps://thuviencine.com/country/germany/',
            'Greece': 'vmfhttps://thuviencine.com/country/greece/',
            'Hong Kong': 'vmfhttps://thuviencine.com/country/hong-kong/',
            'Hungary': 'vmfhttps://thuviencine.com/country/hungary/',
            'Iceland': 'vmfhttps://thuviencine.com/country/iceland/',
            'India': 'vmfhttps://thuviencine.com/country/india/',
            'Indonesia': 'vmfhttps://thuviencine.com/country/indonesia/',
            'Ireland': 'vmfhttps://thuviencine.com/country/ireland/',
            'Israel': 'vmfhttps://thuviencine.com/country/israel/',
            'Italy': 'vmfhttps://thuviencine.com/country/italy/',
            'Japan': 'vmfhttps://thuviencine.com/country/japan/',
            'Korea': 'vmfhttps://thuviencine.com/country/korea/',
            'Latvia': 'vmfhttps://thuviencine.com/country/latvia/',
            'Lithuania': 'vmfhttps://thuviencine.com/country/lithuania/',
            'Luxembourg': 'vmfhttps://thuviencine.com/country/luxembourg/',
            'Malaysia': 'vmfhttps://thuviencine.com/country/malaysia/',
            'Mexico': 'vmfhttps://thuviencine.com/country/mexico/',
            'Mỹ': 'vmfhttps://thuviencine.com/country/my/',
            'N/A': 'vmfhttps://thuviencine.com/country/n-a/',
            'Netherlands': 'vmfhttps://thuviencine.com/country/netherlands/',
            'New Zealand': 'vmfhttps://thuviencine.com/country/new-zealand/',
            'Nigeria': 'vmfhttps://thuviencine.com/country/nigeria/',
            'Norway': 'vmfhttps://thuviencine.com/country/norway/',
            'Peru': 'vmfhttps://thuviencine.com/country/peru/',
            'Philippines': 'vmfhttps://thuviencine.com/country/philippines/',
            'Phim bộ Mỹ': 'vmfhttps://thuviencine.com/country/phim-bo-my/',
            'Poland': 'vmfhttps://thuviencine.com/country/poland/',
            'Portugal': 'vmfhttps://thuviencine.com/country/portugal/',
            'Romania': 'vmfhttps://thuviencine.com/country/romania/',
            'Russia': 'vmfhttps://thuviencine.com/country/russia/',
            'Singapore': 'vmfhttps://thuviencine.com/country/singapore/',
            'Slovakia': 'vmfhttps://thuviencine.com/country/slovakia/',
            'South Africa': 'vmfhttps://thuviencine.com/country/south-africa/',
            'South Korea': 'vmfhttps://thuviencine.com/country/south-korea/',
            'Spain': 'vmfhttps://thuviencine.com/country/spain/',
            'Sweden': 'vmfhttps://thuviencine.com/country/sweden/',
            'Switzerland': 'vmfhttps://thuviencine.com/country/switzerland/',
            'Taiwan': 'vmfhttps://thuviencine.com/country/taiwan/',
            'Thailand': 'vmfhttps://thuviencine.com/country/thailand/',
            'Tunisia': 'vmfhttps://thuviencine.com/country/tunisia/',
            'Turkey': 'vmfhttps://thuviencine.com/country/turkey/',
            'UK': 'vmfhttps://thuviencine.com/country/uk/',
            'Ukraine': 'vmfhttps://thuviencine.com/country/ukraine/',
            'Uruguay': 'vmfhttps://thuviencine.com/country/uruguay/',
            'Venezuela': 'vmfhttps://thuviencine.com/country/venezuela/'
        }

        items = []
        for country, link in country_urls.items():
            item = {
                "label": country,
                "is_playable": False,
                "path": addon_url + "browse&url=" + link,
                "thumbnail": "",
                "icon": "",
                "label2": "",
                "info": {'plot': ''}
            }
            items.append(item)

        data = {"content_type": "episodes", "items": items}
        return data

    elif "chatluong" in url:
        links=['vmfhttps://thuviencine.com/quality/vietsub/', 'vmfhttps://thuviencine.com/quality/tm-pd/', 'vmfhttps://thuviencine.com/quality/tm-lt-pd/', 'vmfhttps://thuviencine.com/quality/tm/', 'vmfhttps://thuviencine.com/quality/raw/', 'vmfhttps://thuviencine.com/quality/phim-viet/', 'vmfhttps://thuviencine.com/quality/new/', 'vmfhttps://thuviencine.com/quality/lt-pd/', 'vmfhttps://thuviencine.com/quality/lt/', 'vmfhttps://thuviencine.com/quality/hd/', 'vmfhttps://thuviencine.com/quality/engsub/', 'vmfhttps://thuviencine.com/quality/cam-vietsub/', 'vmfhttps://thuviencine.com/quality/cam/', 'vmfhttps://thuviencine.com/quality/bluray-vietsub/', 'vmfhttps://thuviencine.com/quality/bluray-tm-pd/', 'vmfhttps://thuviencine.com/quality/bluray/', 'vmfhttps://thuviencine.com/quality/4k-vietsub/', 'vmfhttps://thuviencine.com/quality/4k-tm/', 'vmfhttps://thuviencine.com/quality/4k-lt/', 'vmfhttps://thuviencine.com/quality/4k/']
        names= ['Vietsub', 'TM - PĐ', 'TM - LT - PĐ', 'TM', 'Raw', 'Phim Việt', 'NEW', 'LT - PĐ', 'LT', 'HD', 'Engsub', 'CAM Vietsub', 'CAM', 'Bluray Vietsub', 'Bluray TM - PĐ', 'Bluray', '4K Vietsub', '4K TM', '4K LT', '4K']
        items = []
        for name, link in zip(names,links):
            item = {}
            item["label"] = name
            item["is_playable"] = False
            item["path"] = addon_url + "browse&url="+link
            item["thumbnail"] = ""
            item["icon"] = ""
            item["label2"] = ""
            item["info"] = {'plot': ''}
            items += [item]
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        return data
    elif "/timkiem/" in url:

        def load_history():
            return tvcine_history.get_history()

        def save_history(query):
            tvcine_history.save_history(query)

        def clear_history():
            tvcine_history.delete_history()
            notify("Đã xóa lịch sử tìm kiếm")

        history = load_history()

        dialog = xbmcgui.Dialog()
        if history:
            options = ["[COLOR yellow]Nhập từ khóa mới[/COLOR]", "[COLOR yellow]Xóa lịch sử[/COLOR]"] + history
            choice = dialog.select("Chọn hoặc nhập từ khóa tìm kiếm:", options)

            if choice == -1:
                notify("Bạn đã hủy tìm kiếm")
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
                return None

            if choice == 0:
                keyboard = xbmc.Keyboard("", "Nhập tên phim tiếng Anh")
                keyboard.doModal()
                if keyboard.isConfirmed() and keyboard.getText():
                    query = keyboard.getText()
                    query = urllib.parse.unquote(query)
                    save_history(query)
                    url = "https://thuviencine.com/?s=%s" % query
                    data = listMovie(url)
                    return data
                else:
                    notify("Hủy tìm kiếm")
                    xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
                    return None
            elif choice == 1:
                confirm = dialog.yesno("Xác nhận", "Bạn có chắc chắn muốn xóa toàn bộ lịch sử tìm kiếm không?")
                if confirm:
                    clear_history()
                return None
            elif choice > 1:
                query = history[choice - 2]
                url = "https://thuviencine.com/?s=%s" % query
                data = listMovie(url)
                return data
        else:

            keyboard = xbmc.Keyboard("", "Nhập tên phim tiếng Anh")
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():
                query = keyboard.getText()
                query = urllib.parse.unquote(query)
                save_history(query)
                url = "https://thuviencine.com/?s=%s" % query
                data = listMovie(url)
                return data
            else:
                notify("Hủy tìm kiếm")
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
                return

    else:
        cache_key = hashlib.md5(url.encode()).hexdigest() + "_detail"
        if cache_utils.check_cache(cache_key):
            cache_content = cache_utils.get_cache(cache_key)
            if cache_content:
                return cache_content
        dialog = xbmcgui.DialogProgress()
        dialog.create('Đang tải dữ liệu', 'Vui lòng đợi...')

        try:

            response = session.get(url, verify=False, timeout=30)
            response.raise_for_status()
            dialog.update(50, 'Phân tích dữ liệu...')
            soup = BeautifulSoup(response.content, "html.parser")
            movie_image = soup.find("div", class_="movie-image")
            movie_description = soup.find("p", class_="movie-description")
        except (ConnectionError, Timeout) as e:
            dialog.close()
            alert(f'Lỗi kết nối: {str(e)}')
            return None
        except RequestException as e:
            dialog.close()
            alert(f'Lỗi khi tải trang: {str(e)}')
            return None

        movie_title = soup.find("h1", {"itemprop": "name", "class": "entry-title"})
        english_name = None
        if movie_title:
            full_name = movie_title.text.strip()

            if "–" in full_name or "-" in full_name:
                full_name = full_name.replace("–", "-")
                full_name = re.sub(r'\s*-\s*', ' - ', full_name)
                name_parts = full_name.split(" - ")
                if len(name_parts) > 1:
                    english_name = name_parts[1].strip()
                    # Loại bỏ các ký tự đặc biệt
                    english_name = re.sub(r'[:"\'[\](){},!?@#$%^&*]', '', english_name)
                    # Loại bỏ khoảng trắng thừa
                    english_name = re.sub(r'\s+', ' ', english_name).strip()

        if movie_description:
            description_span = movie_description.find("span", itemprop="description")
            if description_span:
                description = description_span.text.strip()
                description = re.sub(r'^Nội dung phim.*?fshare:\s*', '', description, flags=re.IGNORECASE)
                description = re.sub(r';\s*Trên đây là nội dung phim.*?$', '', description, flags=re.IGNORECASE)
                description = description.strip()
            else:
                description = "Không tìm thấy mô tả phim."
        else:
            description = "Không tìm thấy phần tử chứa mô tả phim."

        if movie_image:
            image = movie_image.find("img")["src"]
        else:
            image=""
        dialog.update(75, 'Lấy link phim...')

        # Bước 1: Tìm link download button
        download_page_url = None
        download_button = soup.find("li", id="download-button")
        if download_button:
            download_a = download_button.find("a")
            if download_a and "href" in download_a.attrs:
                download_page_url = download_a["href"]
                xbmc.log(f"[VietmediaF] Tìm thấy link download page: {download_page_url}", xbmc.LOGINFO)

        # Nếu không tìm thấy download button, thử các cách khác
        if not download_page_url:
            # Tìm theo text="Download"
            download_a = soup.find("a", text=lambda text: text and "Download" in text)
            if download_a and "href" in download_a.attrs:
                download_page_url = download_a["href"]

        # Nếu tìm thấy link download page
        if download_page_url:
            try:
                dialog.update(80, 'Truy cập trang download...')
                # Truy cập trang download để lấy link fshare
                download_response = session.get(download_page_url, verify=False, timeout=30)
                download_response.raise_for_status()
                download_soup = BeautifulSoup(download_response.content, "html.parser")

                # Tìm div class="movie-actions"
                movie_actions = download_soup.find("div", class_="movie-actions")
                if movie_actions:
                    # Tìm tất cả link fshare trong div
                    fshare_links = movie_actions.find_all("a", href=lambda href: href and "fshare.vn" in href)
                    if fshare_links:
                        # Lấy link fshare đầu tiên
                        fshare_link = fshare_links[0]["href"]
                        xbmc.log(f"[VietmediaF] Tìm thấy link fshare: {fshare_link}", xbmc.LOGINFO)

                        # Gọi hàm getlink để xử lý link fshare
                        data = getlink(fshare_link, image, description, english_name)
                        if data:
                            cache_utils.set_cache(cache_key, data)
                        dialog.close()
                        return data

                # Nếu không tìm thấy trong div class="movie-actions", tìm trong toàn bộ trang
                if not movie_actions or not fshare_links:
                    fshare_links = download_soup.find_all("a", href=lambda href: href and "fshare.vn" in href)
                    if fshare_links:
                        fshare_link = fshare_links[0]["href"]
                        xbmc.log(f"[VietmediaF] Tìm thấy link fshare trong toàn trang: {fshare_link}", xbmc.LOGINFO)

                        data = getlink(fshare_link, image, description, english_name)
                        if data:
                            cache_utils.set_cache(cache_key, data)
                        dialog.close()
                        return data

            except Exception as e:
                xbmc.log(f"[VietmediaF] Lỗi khi truy cập trang download: {str(e)}", xbmc.LOGERROR)

        # Nếu không tìm thấy link fshare từ trang download, thử tìm trực tiếp trong trang hiện tại
        fshare_links = soup.find_all("a", href=lambda href: href and "fshare.vn" in href)
        if fshare_links:
            fshare_link = fshare_links[0]["href"]
            xbmc.log(f"[VietmediaF] Tìm thấy link fshare trực tiếp: {fshare_link}", xbmc.LOGINFO)

            data = getlink(fshare_link, image, description, english_name)
            if data:
                cache_utils.set_cache(cache_key, data)
            dialog.close()
            return data

        # Nếu không tìm thấy link fshare, thử tìm kiếm trực tiếp bằng tên phim tiếng Anh
        if english_name:
            dialog.update(85, 'Tìm kiếm trực tiếp trên Fshare...')
            data_timfshare = timfshare(english_name)
            if data_timfshare and "items" in data_timfshare and data_timfshare["items"]:
                for item in data_timfshare["items"]:
                    item["thumbnail"] = image
                    item["icon"] = image
                    if "info" in item:
                        item["info"]["plot"] = description
                    else:
                        item["info"] = {"plot": description}
                    item["art"] = {
                        "fanart": image,
                        "icon": image,
                        "thumb": image,
                        "poster": image
                    }

                cache_utils.set_cache(cache_key, data_timfshare)
                dialog.close()
                return data_timfshare

        dialog.close()
        alert("Không tìm thấy link download. Thử lại sau hoặc tìm kiếm trực tiếp trên Fshare.")
        return None

def parse_movie_info(soup, img, vietsub, link):
    """Parse thông tin chi tiết phim từ trang con"""
    item = {}

    try:
        # Lấy tên phim (tiếng Việt) theo mã HTML mới
        title_h1 = soup.find('h1', itemprop='name', class_='entry-title')
        if not title_h1:
            title_h1 = soup.find('h1', class_='entry-title')
        name = title_h1.text.strip() if title_h1 else ""

        # Lấy tên tiếng Anh và năm sản xuất từ tiêu đề
        name_en = ""
        year = None

        # Xử lý cả trường hợp dấu gạch ngang thường và dấu gạch ngang dài
        if " – " in name:
            name_parts = name.split(" – ")
            name = name_parts[0].strip()
            name_en = name_parts[1].strip()
        elif " - " in name:
            name_parts = name.split(" - ")
            name = name_parts[0].strip()
            name_en = name_parts[1].strip()

        # Tìm năm sản xuất trong tên tiếng Anh hoặc tiêu đề gốc
        year_match = re.search(r'\((\d{4})\)', name)
        if not year_match and name_en:
            year_match = re.search(r'\((\d{4})\)', name_en)
        if not year_match:
            year_match = re.search(r'(\d{4})', name_en)

        if year_match:
            year = year_match.group(1)
            # Loại bỏ năm khỏi tên tiếng Anh nếu có
            name_en = re.sub(r'\s*\(\d{4}\)', '', name_en).strip()

        # Lấy thể loại phim theo mã HTML mới
        genre = ""
        genre_span = soup.find('span', itemprop='genre')
        if genre_span:
            genre_links = genre_span.find_all('a')
            if genre_links:
                genre = ", ".join([link.text.strip() for link in genre_links])

        # Nếu không tìm thấy thể loại, thử các cách khác
        if not genre:
            genre_links = soup.find_all('a', href=lambda href: href and ('phim-' in href or 'the-loai' in href))
            if genre_links:
                genre = ", ".join([link.text.strip() for link in genre_links])

        # Lấy mô tả phim theo mã HTML mới
        description = ""
        description_span = soup.find('span', itemprop='description', class_='trama')
        if description_span:
            description = description_span.text.strip()
            # Xử lý mô tả để loại bỏ phần "Trên đây là nội dung phim..."
            if "Trên đây là nội dung phim" in description:
                description = description.split("Trên đây là nội dung phim")[0].strip()

        # Nếu không tìm thấy mô tả, thử các cách khác
        if not description:
            # Tìm trong các thẻ p có class="movie-description"
            desc_p = soup.find('p', class_='movie-description')
            if desc_p:
                description = desc_p.text.strip()
                if "Trên đây là nội dung phim" in description:
                    description = description.split("Trên đây là nội dung phim")[0].strip()

        # Nếu vẫn không tìm thấy, tìm trong toàn bộ nội dung
        if not description:
            entry_content = soup.find('div', class_='entry-content')
            if entry_content:
                info_text = entry_content.get_text()
                description_match = re.search(r'Nội dung phim.*?fshare:\s*(.*?)(?:Trên \u0111\u00e2y l\u00e0 n\u1ed9i dung phim|$)', info_text, re.DOTALL)
                if description_match:
                    description = description_match.group(1).strip()

        # Lấy trailer theo mã HTML mới
        trailer_id = None
        trailer_link = soup.find('a', id='hover', href=lambda href: href and 'youtube.com/watch' in href)
        if trailer_link:
            youtube_id_match = re.search(r'(?:v=|\/)([\w-]+)(?:&|\?|$)', trailer_link['href'])
            if youtube_id_match:
                trailer_id = youtube_id_match.group(1)

        # Nếu không tìm thấy trailer, thử các cách khác
        if not trailer_id:
            # Tìm trong iframe
            iframe = soup.find('iframe', src=lambda src: src and 'youtube.com/embed/' in src)
            if iframe:
                trailer_id = iframe['src'].split('/')[-1].split('?')[0]
            else:
                # Tìm trong các thẻ a có text là "Trailer"
                trailer_link = soup.find('a', text=lambda text: text and 'Trailer' in text)
                if trailer_link and 'youtube.com' in trailer_link.get('href', ''):
                    youtube_id_match = re.search(r'(?:v=|\/)([\w-]+)(?:&|\?|$)', trailer_link['href'])
                    if youtube_id_match:
                        trailer_id = youtube_id_match.group(1)

        # Lấy thông tin đạo diễn và diễn viên
        director = ""
        cast = ""

        # Tìm đạo diễn trong các thẻ a có href chứa "director"
        director_links = soup.find_all('a', href=lambda href: href and 'director' in href)
        if director_links:
            director = ", ".join([link.text.strip() for link in director_links])

        # Tìm diễn viên trong các thẻ a có href chứa "actors"
        actor_links = soup.find_all('a', href=lambda href: href and 'actors' in href)
        if actor_links:
            cast = ", ".join([link.text.strip() for link in actor_links])

        # Tìm thời lượng phim
        duration = None
        duration_text = soup.find(text=lambda text: text and 'phút' in text)
        if duration_text:
            duration_match = re.search(r'(\d+)\s*phút', duration_text)
            if duration_match:
                duration = duration_match.group(1)

        # Tạo cấu trúc item theo format chuẩn
        item["label"] = f"{name} [COLOR yellow]{vietsub}[/COLOR]"
        item["is_playable"] = False
        item["path"] = link
        item["thumbnail"] = img
        item["icon"] = img
        item["art"] = {
            'thumb': img,
            'icon': img,
            'poster': img,
            'fanart': img
        }

        # Thêm tên phim vào label2 để hiển thị ở các mục đặc biệt
        if name_en:
            item["label2"] = f"{name} - {name_en}"
        else:
            item["label2"] = name

        # Info theo format trong loadlistitem.py
        item["info"] = {
            'title': name,
            'originaltitle': name_en,
            'plot': description,
            'genre': genre,
            'director': director,
            'cast': [x.strip() for x in cast.split(',')] if cast else [],
            'duration': int(duration) if duration else 0,
            'year': int(year) if year else 0,
            'mediatype': 'movie'
        }

        if trailer_id:
            item["info"]["trailer"] = f'plugin://plugin.video.youtube/?action=play_video&videoid={trailer_id}'

    except Exception as e:
        xbmc.log(f"[VietmediaF] Lỗi khi parse thông tin phim: {str(e)}", xbmc.LOGERROR)
        # Tạo item đơn giản nếu có lỗi
        item["label"] = link.split('/')[-2].replace('-', ' ').title()
        item["is_playable"] = False
        item["path"] = link
        item["thumbnail"] = img
        item["icon"] = img
        item["label2"] = link.split('/')[-2].replace('-', ' ').title()  # Thêm tên phim vào label2
        item["info"] = {'plot': 'Không thể lấy thông tin phim'}

    return item

'''
Ghi chú/mẫu code cho hàm getlist:

for div in divs:
    # Lấy link và img như code cũ
    link = div.find("a")["href"]
    img = div.find("img", class_="lazy")
    if img:
        img = img.get("data-src")

    # Lấy thông tin vietsub
    vietsub = div.find("span", class_=lambda value: value and value.startswith("item-quality"))
    vietsub = vietsub.text.strip() if vietsub else "No sub"

    # Parse thông tin chi tiết
    try:
        response = session.get(link, verify=False, timeout=30)
        soup = BeautifulSoup(response.content, "html.parser")
        item = parse_movie_info(soup, img, vietsub, link)
        items.append(item)
    except Exception as e:
        xbmc.log(f"[VietmediaF] Lỗi khi parse trang chi tiết: {str(e)}", xbmc.LOGERROR)
        continue
'''
