import os
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import zipfile
import urllib.request
import shutil
from resources.addon import notify, alert, ADDON_PATH, ADDON_NAME

def install_arctic_zephyr():
    """
    Cài đặt skin Arctic Zephyr Mod và các file cấu hình
    """
    try:
        
        skin_installed = xbmc.getCondVisibility('System.HasAddon(skin.arctic.zephyr.mod)')

        if not skin_installed:
            
            dialog = xbmcgui.Dialog()
            if dialog.yesno("Cài đặt Skin", "Skin Arctic Zephyr chưa được cài đặt.\n\nBạn có muốn cài đặt luôn Skin Arctic Zephyr từ repository của Kodi không?"):
                
                xbmc.executebuiltin('InstallAddon(skin.arctic.zephyr.mod)')

                
                alert("Skin đang được cài đặt. Sau khi cài đặt xong, hãy quay lại đây để copy các file cấu hình.")
            else:
                
                alert("Bạn vào Settings/ Giao diện/ Skin và cài đặt skin Arctic Zephyr nhé")
                xbmc.executebuiltin('ActivateWindow(InterfaceSettings)')
            return False
        else:
            
            dialog = xbmcgui.Dialog()
            if dialog.yesno("Copy các file cấu hình",
                           "Skin Arctic Zephyr Mod đã được cài đặt.\n\n"
                           "Bây giờ chúng tôi sẽ:\n"
                           "- Copy guisettings.xml vào thư mục userdata\n"
                           "- Giải nén các file cấu hình vào thư mục addon_data\n\n"
                           "Bạn có muốn tiếp tục không?"):

                
                progress_dialog = xbmcgui.DialogProgress()
                progress_dialog.create("Copy các file cấu hình", "Đang chuẩn bị copy các file cấu hình...")
                progress_dialog.update(10)

                
                progress_dialog.update(50, "Đang copy các file cấu hình...")
                if extract_skin_config_files():
                    progress_dialog.update(100, "Hoàn tất!")
                    progress_dialog.close()

                    
                    if dialog.yesno("Hoàn tất",
                                   "Các file cấu hình đã được copy thành công.\n\n"
                                   "Để áp dụng các thay đổi, bạn cần khởi động lại Kodi.\n\n"
                                   "Bạn có muốn khởi động lại Kodi ngay bây giờ không?"):
                        xbmc.executebuiltin('RestartApp')
                    return True
                else:
                    progress_dialog.close()
                    alert("Không thể copy các file cấu hình. Vui lòng thử lại sau.")
                    return False
            else:
                return False

    except Exception as e:
        xbmc.log(f"[VietmediaF] Lỗi khi cài đặt skin: {str(e)}", xbmc.LOGERROR)
        alert(f"Lỗi khi cài đặt skin: {str(e)}")
        return False

def extract_skin_config_files():
    """
    Copy guisettings.xml vào userdata và giải nén các file cấu hình skin vào thư mục addon_data

    Returns:
        bool: True nếu thành công, False nếu có lỗi
    """
    try:
        
        userdata_path = xbmcvfs.translatePath('special://userdata')
        addon_data_path = os.path.join(userdata_path, 'addon_data')

        
        if not os.path.exists(addon_data_path):
            os.makedirs(addon_data_path)

        
        guisettings_path = os.path.join(ADDON_PATH, 'resources', 'skins', 'guisettings.xml')
        skin_zip_path = os.path.join(ADDON_PATH, 'resources', 'skins', 'skin.arctic.zephyr.mod.zip')
        shortcuts_zip_path = os.path.join(ADDON_PATH, 'resources', 'skins', 'script.skinshortcuts.zip')

        
        files_missing = False
        missing_files = []

        if not os.path.exists(guisettings_path):
            files_missing = True
            missing_files.append("guisettings.xml")

        if not os.path.exists(skin_zip_path):
            files_missing = True
            missing_files.append("skin.arctic.zephyr.mod.zip")

        if not os.path.exists(shortcuts_zip_path):
            files_missing = True
            missing_files.append("script.skinshortcuts.zip")

        if files_missing:
            
            dialog = xbmcgui.Dialog()
            if dialog.yesno("Cấu hình skin", f"Các file cấu hình skin sau không tồn tại: {', '.join(missing_files)}\n\nBạn có muốn tiếp tục mà không có các file này không?"):
                
                notify("Tiếp tục mà không có đầy đủ file cấu hình")
            else:
                
                return False

        
        if os.path.exists(guisettings_path):
            try:
                
                shutil.copy2(guisettings_path, userdata_path)
                xbmc.log(f"[VietmediaF] Đã copy guisettings.xml vào {userdata_path}", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[VietmediaF] Lỗi khi copy guisettings.xml: {str(e)}", xbmc.LOGERROR)
                alert(f"Lỗi khi copy guisettings.xml: {str(e)}")

        
        if os.path.exists(skin_zip_path):
            with zipfile.ZipFile(skin_zip_path, 'r') as zip_ref:
                zip_ref.extractall(addon_data_path)
                xbmc.log(f"[VietmediaF] Đã giải nén skin.arctic.zephyr.mod.zip vào {addon_data_path}", xbmc.LOGINFO)

        if os.path.exists(shortcuts_zip_path):
            with zipfile.ZipFile(shortcuts_zip_path, 'r') as zip_ref:
                zip_ref.extractall(addon_data_path)
                xbmc.log(f"[VietmediaF] Đã giải nén script.skinshortcuts.zip vào {addon_data_path}", xbmc.LOGINFO)

        return True

    except Exception as e:
        xbmc.log(f"[VietmediaF] Lỗi khi copy các file cấu hình: {str(e)}", xbmc.LOGERROR)
        alert(f"Lỗi khi copy các file cấu hình: {str(e)}")
        return False

def download_skin_config_files(skin_zip_path, shortcuts_zip_path):
    """
    Tải các file cấu hình skin từ internet

    Args:
        skin_zip_path (str): Đường dẫn để lưu file skin.arctic.zephyr.mod.zip
        shortcuts_zip_path (str): Đường dẫn để lưu file script.skinshortcuts.zip

    Returns:
        bool: True nếu tải thành công, False nếu có lỗi
    """
    try:
        
        dialog = xbmcgui.Dialog()
        if not dialog.yesno("Tải cấu hình skin", "Cần tải các file cấu hình skin từ internet. Bạn có muốn tiếp tục không?"):
            return False

        
        progress_dialog = xbmcgui.DialogProgress()
        progress_dialog.create("Đang tải cấu hình skin", "Đang chuẩn bị tải các file cấu hình...")
        progress_dialog.update(10)

        
        skin_zip_url = "https://example.com/skin.arctic.zephyr.mod.zip"
        shortcuts_zip_url = "https://example.com/script.skinshortcuts.zip"

        
        progress_dialog.update(30, "Đang tải file cấu hình skin...")

        
        try:
            urllib.request.urlretrieve(skin_zip_url, skin_zip_path)
            progress_dialog.update(60, "Đang tải file cấu hình shortcuts...")
            urllib.request.urlretrieve(shortcuts_zip_url, shortcuts_zip_path)
            progress_dialog.update(100, "Hoàn tất tải các file cấu hình!")
        except Exception as e:
            progress_dialog.close()
            alert(f"Không thể tải các file cấu hình: {str(e)}")
            return False

        progress_dialog.close()
        return True

    except Exception as e:
        xbmc.log(f"[VietmediaF] Lỗi khi tải file cấu hình skin: {str(e)}", xbmc.LOGERROR)
        alert(f"Lỗi khi tải file cấu hình skin: {str(e)}")
        return False

def display_skin_installer_menu():
    """
    Hiển thị menu cài đặt skin
    """
    import sys
    import xbmcplugin
    from resources.utils import add_menu_item

    handle = int(sys.argv[1])

    skin_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'skin.png')
    help_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'help.png')

    
    if not os.path.exists(help_icon):
        help_icon = skin_icon

    
    skin_installed = xbmc.getCondVisibility('System.HasAddon(skin.arctic.zephyr.mod)')

    if skin_installed:
        add_menu_item(handle, "Copy các file cấu hình cho Skin Arctic Zephyr",
                     "plugin://plugin.video.vietmediaF?action=install_arctic_zephyr",
                     False, skin_icon,
                     "Copy các file cấu hình và khởi động lại Kodi")
    else:
        add_menu_item(handle, "Cài đặt Skin Arctic Zephyr",
                     "plugin://plugin.video.vietmediaF?action=install_arctic_zephyr",
                     False, skin_icon,
                     "Cài đặt skin Arctic Zephyr Mod và giải nén các file cấu hình")

    add_menu_item(handle, "Hướng dẫn cài đặt thủ công",
                 "plugin://plugin.video.vietmediaF?action=show_skin_install_guide",
                 False, help_icon,
                 "Xem hướng dẫn cài đặt skin Arctic Zephyr Mod thủ công")

    xbmcplugin.endOfDirectory(handle)


def show_skin_install_guide():
    """
    Hiển thị hướng dẫn cài đặt skin thủ công
    """
    try:
        
        guide_path = os.path.join(ADDON_PATH, 'resources', 'skins', 'README_INSTALL.txt')

        
        if not os.path.exists(guide_path):
            alert("Không tìm thấy file hướng dẫn cài đặt.")
            return

        
        with open(guide_path, 'r', encoding='utf-8') as f:
            guide_content = f.read()

        
        from resources.utils import TextBoxes
        TextBoxes("Hướng dẫn cài đặt skin Arctic Zephyr Mod", guide_content)

    except Exception as e:
        xbmc.log(f"[VietmediaF] Lỗi khi hiển thị hướng dẫn cài đặt: {str(e)}", xbmc.LOGERROR)
        alert(f"Lỗi khi hiển thị hướng dẫn cài đặt: {str(e)}")

