# Tài liệu mô tả luồng xử lý trong tvcine.py

## 1. Luồng xử lý chính

### 1.1. Hiển thị Menu Chính
- Hàm `receive(url)` xử lý khi có "menu" trong url
- Tạo danh sách menu: Tìm kiếm, Phim Lẻ, Phim Bộ, Xu hướng, Thể loại, Quốc gia, Chất lượng
- Mỗi item menu được gán URL tương ứng trên thuviencine.com

### 1.2. Xử lý Danh sách Phim
- Hàm `listMovie(url)` là hàm chính xử lý hiển thị danh sách phim
- Quy trình:
  1. Kiểm tra cache với key = md5(url) + "_movie_list"
  2. Nếu có cache -> trả về data từ cache
  3. Nếu không có cache -> gọi hàm `getlist(url)`
  4. Lưu kết quả vào cache

### 1.3. Chi tiết Phim & Link Fshare
Khi click vào một phim:
1. Gọi hàm xử lý trong khối `else` cuối của `receive(url)`
2. Quy trình:
   - Tạo cache_key = md5(url) + "_detail"
   - Parse HTML để lấy thông tin phim (ảnh, mô tả, tên tiếng Anh)
   - Tìm nút download để lấy link
   - Gọi hàm `getlink(link, image, description, english_name)`

## 2. Các Hàm Chính và Chức năng

### 2.1. receive(url)
- Điểm vào chính của module
- Xử lý các loại URL:
  - menu: Hiển thị menu chính
  - tv-series/top/movies: Gọi listMovie
  - theloai: Hiển thị danh sách thể loại
  - quocgia: Hiển thị danh sách quốc gia
  - chatluong: Hiển thị danh sách chất lượng
  - timkiem: Xử lý tìm kiếm và lịch sử
  - URL khác: Xử lý trang chi tiết phim

### 2.2. listMovie(url)
- Xử lý hiển thị danh sách phim
- Sử dụng cache để tối ưu
- Gọi getlist(url) để lấy dữ liệu mới
- Xử lý phân trang

### 2.3. getlist(url)
- Parse HTML trang danh sách phim
- Lấy thông tin cơ bản: tên, ảnh, chất lượng
- Tạo next page nếu có
- Trả về data dạng {"content_type": "movies", "items": [...]}

### 2.4. getlink(url, img, description, english_name)
- Lấy và xử lý các link Fshare
- Tạo item cho mỗi link với:
  - Label: tên file
  - Path: URL plugin để play
  - Thumbnail/icon: ảnh phim
  - Info: mô tả, kích thước
- Cache kết quả với timeout

## 3. Xử lý Cache

- Sử dụng 2 loại cache:
  1. Cache danh sách phim: key = md5(url) + "_movie_list"
  2. Cache chi tiết phim: key = md5(url) + "_detail"
  3. Cache link Fshare: key = md5(url) + "_links"

## 4. Luồng Tìm kiếm

1. Hiển thị dialog với options:
   - Nhập từ khóa mới
   - Xóa lịch sử
   - Danh sách lịch sử tìm kiếm
2. Xử lý lựa chọn:
   - Từ khóa mới: Lưu vào lịch sử và tìm
   - Xóa lịch sử: Xác nhận và xóa
   - Chọn từ lịch sử: Tìm lại với từ khóa đã chọn