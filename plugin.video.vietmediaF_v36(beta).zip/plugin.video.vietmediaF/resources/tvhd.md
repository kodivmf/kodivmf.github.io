# TVHD Module Documentation

## 1. Tổng quan
[phần cũ giữ nguyên...]

## 2. Các Hàm Chính & Workflow

### 2.1. search(page, query)
#### Workflow:
```mermaid
graph TD
    A[Bắt đầu] --> B[Tạo search_url]
    B --> C{Kiểm tra cache?}
    C -->|Có| D[Trả về cache_data]
    C -->|Không| E[Gửi GET request]
    E --> F[Parse HTML]
    F --> G[Tạo items list]
    G --> H{Có trang tiếp?}
    H -->|Có| I[Thêm next_page item]
    H -->|Không| J[Tạo response data]
    I --> J
    J --> K[Lưu cache]
    K --> L[Trả về data]
```

### 2.2. listGenre(url) 
#### Workflow:
```mermaid
graph TD
    A[Bắt đầu] --> B[Tạo cache_key]
    B --> C{Check cache?}
    C -->|Có| D[Return cache]
    C -->|Không| E[Gọi listGenre_]
    E --> F[GET request]
    F --> G[Parse articles]
    G --> H[Process mỗi article]
    H --> I[Lấy: img/href/name/imdb]
    I --> J[Tạo item object]
    J --> K{Check pagination}
    K -->|Có| L[Thêm next page]
    K -->|Không| M[Tạo response]
    L --> M
    M --> N[Save cache]
    N --> O[Return data]
```

### 2.3. listMovie(url)
#### Workflow:
```mermaid
graph TD
    A[Bắt đầu] --> B[Check cache]
    B -->|Cache hit| C[Return cache]
    B -->|Cache miss| D[Gọi listMovie_]
    D --> E[GET request với retry]
    E --> F[Parse HTML]
    F --> G[Tạo ThreadPool]
    G --> H[Process song song các div]
    H --> I[get_info cho mỗi phim]
    I --> J[Tạo item objects]
    J --> K{Check pagination}
    K -->|Có| L[Thêm next page]
    K -->|Không| M[Tạo response]
    L --> M
    M --> N[Save cache]
    N --> O[Return data]

    subgraph get_info
    P[GET request] --> Q[Parse details]
    Q --> R[Extract name/desc/genre]
    end
```

### 2.4. receive(url)
#### Workflow:
```mermaid
graph TD
    A[Nhận URL] --> B{Kiểm tra loại URL}
    B -->|menu| C[Tạo menu items]
    B -->|trending/recent| D[Xử lý danh sách phim]
    B -->|theloai| E[Hiển thị thể loại]
    B -->|timkiem| F[Xử lý tìm kiếm]
    B -->|?s=| G[Xử lý kết quả tìm kiếm]
    B -->|genre| H[Xử lý thể loại]
    B -->|other| I[Xử lý chi tiết phim]

    C --> J[Return data]
    D --> J
    E --> J
    F --> J
    G --> J
    H --> J
    I --> J
```

## 3. Chi Tiết Xử Lý Các Luồng

### 3.1. Luồng Tìm Kiếm
1. User nhập từ khóa
2. Tạo URL tìm kiếm với page=1
3. Kiểm tra cache
4. Nếu không có cache:
   - Gửi request 
   - Parse kết quả
   - Tạo danh sách items
   - Thêm nút next page
   - Cache kết quả
5. Trả về data cho UI

### 3.2. Luồng Xem Thể Loại
1. Nhận URL thể loại
2. Kiểm tra cache
3. Nếu không có cache:
   - GET request lấy trang
   - Parse các article
   - Với mỗi phim:
     * Lấy thông tin cơ bản
     * Tạo item object
   - Kiểm tra phân trang
   - Cache kết quả
4. Trả về data cho UI

### 3.3. Luồng Xem Danh Sách Phim
1. Nhận URL danh sách
2. Kiểm tra cache
3. Nếu không có cache:
   - GET request với retry (3 lần)
   - Parse HTML lấy các div phim
   - Tạo thread pool
   - Mỗi thread xử lý một phim:
     * Parse thông tin cơ bản
     * GET request lấy chi tiết
     * Tạo item đầy đủ
   - Thêm phân trang nếu có
   - Cache kết quả
4. Trả về data cho UI

### 3.4. Luồng Xử Lý Menu
1. Tạo danh sách menu items cố định
2. Với mỗi item:
   - Set label
   - Set URL
   - Set thumbnail/fanart
   - Set thông tin bổ sung
3. Trả về danh sách cho UI

## 4. Xử Lý Cache
### 4.1. Cache Key Generation
- Sử dụng MD5 hash của URL
- Thêm suffix tùy loại data:
  * "_search": Cho kết quả tìm kiếm
  * "_genre": Cho thể loại
  * "_movie_list": Cho danh sách phim

### 4.2. Cache Validation
- Check thời gian tạo cache
- So sánh với timeout (30 phút)
- Xóa cache hết hạn

### 4.3. Cache Storage
- Format JSON
- Lưu vào file system
- Cấu trúc thư mục cache theo ngày

## 5. Xử Lý Lỗi
### 5.1. Network Errors
- Retry logic cho network requests
- Timeout handling
- Connection error handling

### 5.2. Parsing Errors
- Try-catch cho mọi operation
- Fallback values cho missing data
- Log errors qua xbmc.log

### 5.3. Cache Errors
- Validate cache data
- Handle corrupt cache
- Auto-cleanup invalid cache