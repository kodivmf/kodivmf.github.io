# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui

addon = xbmcaddon.Addon()

def auto_start():

    if addon.getSetting('auto_start') == 'true':
        xbmc.executebuiltin('RunAddon(plugin.video.fshare)')

if __name__ == '__main__':
    auto_start() 