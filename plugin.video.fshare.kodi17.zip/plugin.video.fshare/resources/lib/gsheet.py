# -*- coding: utf-8 -*-
import re
import json
import requests

def extract_sheet_info(url):
    
    sheet_id = None
    gid = '0'

    match = re.search(r'/d/([a-zA-Z0-9-_]+)', url)
    if match:
        sheet_id = match.group(1)

    match = re.search(r'gid=(\d+)', url)
    if match:
        gid = match.group(1)
        
    return sheet_id, gid

def get_sheet_data(url):
    
    sheet_id, gid = extract_sheet_info(url)
    if not sheet_id:
        return None
        
    api_url = "https://docs.google.com/spreadsheets/d/{0}/gviz/tq?tqx=out:json&gid={1}".format(
        sheet_id, gid
    )
    
    try:
        response = requests.get(api_url)
        if response.status_code == 200:

            text = response.text
            start_text = "/*O_o*/\ngoogle.visualization.Query.setResponse("
            if text.startswith(start_text):
                json_data = text[len(start_text):-2]
            else:
                json_data = text
            
            data = json.loads(json_data)

            result = []

            for row in data['table']['rows']:
                values = []
                for cell in row['c']:
                    if cell is None:
                        values.append('')
                    else:
                        value = cell.get('v', '')
                        values.append(value)

                if len(values) >= 2 and values[0] and values[1]:

                    if "Title" in str(values[0]):
                        continue
                        
                    item = {}
                    item['name'] = values[0]
                    item['link'] = values[1]
                    item['poster'] = values[2] if len(values) > 2 and values[2] else ''
                    item['pilot'] = values[3] if len(values) > 3 and values[3] else ''
                    result.append(item)
            
            return result
            
    except Exception as e:
        print("Error getting sheet data: " + str(e))
        return None
    
def get_sheet_title(url):
    
    try:
        response = requests.get(url)
        if response.status_code == 200:

            match = re.search(r'<title>(.*?)</title>', response.text)
            if match:
                title = match.group(1)

                title = title.replace(' - Google Sheets', '')
                return title
    except:
        pass
    return None 