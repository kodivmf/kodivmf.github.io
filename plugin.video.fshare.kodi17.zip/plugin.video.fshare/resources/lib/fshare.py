# -*- coding: utf-8 -*-
import sys
import requests
import json
import xbmc
import xbmcgui
import xbmcvfs
import os
import time
import urllib
import xbmcaddon

reload(sys)
sys.setdefaultencoding('utf-8')

API_CONFIG = {
    'BASE_URL': 'https://api.fshare.vn/api',
    'LOGIN_URL': '/user/login',
    'USER_URL': '/user/get', 
    'DOWNLOAD_URL': '/session/download',
    'FOLDER_URL': '/fileops/list',
    'FAVORITE_URL': '/fileops/listFavorite',
    'ADD_FAVORITE_URL': '/fileops/add_favorite',
    'REMOVE_FAVORITE_URL': '/fileops/remove_favorite',
    'TOP_URL': '/files/top',
    'GET_FOLDER_LIST': '/fileops/getFolderList',
    'TOP_FOLLOWS': '/fileops/getTopFollowMovie',
    'CHANGE_FAVORITE': '/fileops/ChangeFavorite'
}

APP_CONFIG = {
    'APP_KEY': 'dMnqMMZMUnN5YpvKENaEhdQQ5jxDqddt',
    'USER_AGENT': 'kodivietmediaf-K58W6U',  
    'VERIFY_SSL': False
}

def log(msg, level=xbmc.LOGNOTICE):
    xbmc.log("FSHARE: %s" % msg, level)

class Fshare(object):
    def __init__(self):
        self.session = requests.Session()
        self.base_url = API_CONFIG['BASE_URL']
        self.token = None
        self.session_id = None
        self.user_agent = APP_CONFIG['USER_AGENT']
        
    def login(self, username, password):
        url = "{0}{1}".format(self.base_url, API_CONFIG['LOGIN_URL'])
        data = {
            "user_email": username,
            "password": password,
            "app_key": APP_CONFIG['APP_KEY']
        }
        
        headers = {
            'User-Agent': self.user_agent,
            'Content-Type': 'application/json'
        }
        
        try:
            log("Trying to login with username: {0}".format(username))
            response = self.session.post(url, json=data, headers=headers, verify=APP_CONFIG['VERIFY_SSL'])
            log("Login response status: {0}".format(response.status_code))
            
            if response.status_code == 200:
                result = response.json()
                log("Login response: {0}".format(json.dumps(result)))
                
                self.token = result.get('token')
                self.session_id = result.get('session_id')
                
                if self.token and self.session_id:
                    current_time = int(time.time())
                    return True, self.token, self.session_id, str(current_time)
                    
            elif response.status_code == 406:
                return False, None, None, None, u"Tài khoản chưa được kích hoạt"
            elif response.status_code == 409:
                return False, None, None, None, u"Tài khoản đã bị khóa login"
            elif response.status_code == 410:
                return False, None, None, None, u"Tài khoản đã bị khóa"
            elif response.status_code == 424:
                return False, None, None, None, u"Tài khoản bị khóa do nhập sai mật khẩu quá 3 lần"
                
            return False, None, None, None, u"Đăng nhập thất bại"
            
        except Exception as e:
            log("Login exception: {0}".format(str(e)), xbmc.LOGERROR)
            return False, None, None, None, str(e)

    def get_user_info(self):
        if not self.token or not self.session_id:
            return None
            
        url = "{0}{1}".format(self.base_url, API_CONFIG['USER_URL'])
        headers = {
            'User-Agent': self.user_agent,
            'Cookie': 'session_id={0}'.format(self.session_id)
        }
        
        try:
            response = self.session.get(url, headers=headers, verify=APP_CONFIG['VERIFY_SSL'])
            if response.status_code == 200:
                return response.json()
        except:
            return None

    def get_direct_link(self, file_url):
        if not self.token or not self.session_id:
            return None
            
        url = "{0}{1}".format(self.base_url, API_CONFIG['DOWNLOAD_URL'])
        headers = {
            'User-Agent': self.user_agent,
            'Cookie': 'session_id={0}'.format(self.session_id)
        }

        data = {
            "zipflag": 0,
            "url": file_url,
            "password": "",
            "token": self.token
        }
        
        try:
            response = self.session.post(url, headers=headers, json=data, verify=APP_CONFIG['VERIFY_SSL'])
            if response.status_code == 200:
                result = response.json()
                return result.get('location')
            else:
                log("Get direct link failed with status: {0}".format(response.status_code))
                log("Response: {0}".format(response.text))
                return None
        except Exception as e:
            log("Get direct link error: {0}".format(str(e)), xbmc.LOGERROR)
            return None

    def get_my_files(self, path='', page_index=0, dir_only=0, limit=60):
        
        if not self.session_id:
            return [], False

        if path == '/':
            path = ''  # Đổi root path "/" thành empty string
        elif path.startswith('/'):
            path = path[1:]  # Bỏ dấu "/" ở đầu path

        url = "{0}/fileops/list".format(self.base_url)

        params = {
            'pageIndex': page_index,
            'dirOnly': dir_only,
            'limit': limit,
            'path': path
        }

        headers = {
            'User-Agent': self.user_agent,
            'Cookie': 'session_id={0}'.format(self.session_id)
        }
        
        try:
            log("Getting my files from URL: {0}".format(url))
            log("With params: {0}".format(json.dumps(params)))
            log("Using session_id: {0}".format(self.session_id))
            
            response = self.session.get(url, headers=headers, params=params, verify=APP_CONFIG['VERIFY_SSL'])
            log("Get my files response status: {0}".format(response.status_code))
            
            if response.status_code == 200:
                data = response.json()
                if not data:
                    return [], False
                    
                log("Got {0} files/folders".format(len(data)))
                log("Sample data: {0}".format(json.dumps(data[0]) if data else "No data"))

                processed_data = []
                for item in data:
                    try:
                        file_info = {
                            'name': item.get('name', ''),
                            'linkcode': item.get('linkcode', ''),
                            'type': str(item.get('type', 1)),  # Convert to string to match existing code
                            'size': item.get('size', 0),
                            'path': item.get('path', path)
                        }
                        processed_data.append(file_info)
                    except Exception as e:
                        log("Error processing file item: {0}".format(str(e)), xbmc.LOGERROR)
                        continue

                has_next = len(data) >= limit
                return processed_data, has_next
                
            else:
                log("Get my files failed with status: {0}".format(response.status_code))
                log("Response content: {0}".format(response.text))
                return [], False
                
        except Exception as e:
            log("Get my files error: {0}".format(str(e)), xbmc.LOGERROR)
            return [], False

    def get_favorites(self, page_index=0, limit=60):
        if not self.token:
            return [], 0
            
        url = "{0}{1}".format(self.base_url, API_CONFIG['FAVORITE_URL'])
        headers = {
            'User-Agent': self.user_agent,
            'Cookie': 'session_id={0}'.format(self.session_id)
        }
        params = {
            "pageIndex": page_index,
            "limit": limit
        }
        
        try:
            response = self.session.get(url, headers=headers, params=params, verify=APP_CONFIG['VERIFY_SSL'])
            data = response.json()
            return data, len(data) >= limit
        except:
            return [], 0

    def add_favorite(self, linkcode):
        
        if not self.token:
            return False, u"Chưa đăng nhập"
            
        url = "{0}{1}".format(self.base_url, API_CONFIG['CHANGE_FAVORITE'])
        headers = {
            'User-Agent': self.user_agent,
            'Cookie': 'session_id={0}'.format(self.session_id)
        }
        
        data = {
            "items": [linkcode],
            "status": 1,  # 1 để thêm vào favorite
            "token": self.token
        }
        
        try:
            log("Adding to favorite: {0}".format(linkcode))
            response = self.session.post(url, headers=headers, json=data, verify=APP_CONFIG['VERIFY_SSL'])
            log("Add favorite response: {0}".format(response.status_code))
            
            if response.status_code == 200:
                return True, u"Đã thêm vào yêu thích"
            elif response.status_code == 404:
                return False, u"Không tìm thấy file/folder"
            elif response.status_code == 409:
                return False, u"File/folder đã có trong danh sách yêu thích"
            else:
                return False, u"Lỗi không xác định (Mã lỗi: {0})".format(response.status_code)
            
        except Exception as e:
            log("Add favorite error: {0}".format(str(e)), xbmc.LOGERROR)
            return False, u"Lỗi kết nối: {0}".format(str(e))

    def remove_favorite(self, file_url):
        if not self.token:
            return False
            
        url = "{0}{1}".format(self.base_url, API_CONFIG['REMOVE_FAVORITE_URL'])
        headers = {
            'User-Agent': self.user_agent,
            'Cookie': 'session_id={0}'.format(self.session_id)
        }
        data = {"link": file_url}
        
        try:
            response = self.session.post(url, headers=headers, json=data, verify=APP_CONFIG['VERIFY_SSL'])
            return response.status_code == 200
        except:
            return False

    def get_top_files(self):
        
        headers = {
            'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
        }
        
        try:
            response = requests.get("https://timfshare.com/api/key/data-top", headers=headers, timeout=30)
            if response.status_code == 200:
                data = response.json()

                video_extensions = ["mkv", "mp4", "avi", "mov", "flv", "wmv", "iso"]
                return [
                    item for item in data.get("dataFile", [])
                    if item.get("file_extension", "").lower() in video_extensions
                ][:100]  # Giới hạn 100 kết quả
            return []
        except Exception as e:
            log("Get top files error: {0}".format(str(e)), xbmc.LOGERROR)
            return []

    def download_file(self, url, dest_path, progress_callback=None):
        direct_url = self.get_direct_link(url)
        if not direct_url:
            return False, "Không thể lấy link tải"

        try:
            response = self.session.get(direct_url, stream=True, verify=APP_CONFIG['VERIFY_SSL'])
            total_size = int(response.headers.get('content-length', 0))
            filename = response.headers.get('filename', 'download.tmp')
            file_path = os.path.join(dest_path, filename)

            if not xbmcvfs.exists(dest_path):
                xbmcvfs.mkdirs(dest_path)
            
            block_size = 1024 * 8  # 8KB
            downloaded = 0
            start_time = time.time()
            
            with open(file_path, 'wb') as f:
                for data in response.iter_content(block_size):

                    if progress_callback and not progress_callback(downloaded, total_size, start_time):
                        f.close()

                        try:
                            os.remove(file_path)
                        except:
                            pass
                        return False, "Đã hủy tải xuống"
                    
                    downloaded += len(data)
                    f.write(data)
                
            return True, file_path
        
        except Exception as e:
            log("Download error: {0}".format(str(e)), xbmc.LOGERROR)
            return False, str(e)

    def get_folder_list(self, folder_url, page_index=0, dir_only=0, limit=60):
        
        if not self.token or not self.session_id:
            log("Missing token or session_id", xbmc.LOGERROR)
            return None, False
        
        url = "{0}{1}".format(self.base_url, API_CONFIG['GET_FOLDER_LIST'])
        headers = {
            'User-Agent': self.user_agent,
            'Cookie': 'session_id={0}'.format(self.session_id),
            'Content-Type': 'application/json'
        }
        
        data = {
            "token": self.token,
            "url": folder_url,
            "dirOnly": dir_only,
            "pageIndex": page_index,
            "limit": limit
        }
        
        try:
            log("Getting folder list - URL: {0}, Data: {1}".format(url, json.dumps(data)))
            response = self.session.post(url, headers=headers, json=data, verify=APP_CONFIG['VERIFY_SSL'])
            log("Folder list response status: {0}".format(response.status_code))
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    if not isinstance(data, list):
                        log("Invalid response data type: {0}".format(type(data)), xbmc.LOGERROR)
                        return None, False
                        
                    log("Got folder data: {0} items".format(len(data)))
                    return data, len(data) >= limit
                    
                except ValueError as e:
                    log("JSON decode error: {0}".format(str(e)), xbmc.LOGERROR)
                    log("Response content: {0}".format(response.text[:200]))  # Log first 200 chars
                    return None, False
            else:
                log("Get folder list failed - Status: {0}, Response: {1}".format(
                    response.status_code, response.text[:200]), xbmc.LOGERROR)
                return None, False
            
        except Exception as e:
            log("Get folder list error: {0}".format(str(e)), xbmc.LOGERROR)
            return None, False

    def get_top_follows(self):
        if not self.token:  # Kiểm tra đã đăng nhập chưa
            return []
        
        url = "{0}{1}".format(self.base_url, API_CONFIG['TOP_FOLLOWS'])
        headers = {
            'User-Agent': self.user_agent,
            'Cookie': 'session_id={0}'.format(self.session_id),  # Thêm session_id
            'Authorization': 'Bearer {0}'.format(self.token)  # Thêm token vào header
        }
        
        try:
            log("Getting top follows from URL: {0}".format(url))
            log("Using token: {0}".format(self.token))
            response = self.session.get(url, headers=headers, verify=APP_CONFIG['VERIFY_SSL'])
            log("Top follows response status: {0}".format(response.status_code))
            
            if response.status_code == 200:
                data = response.json()
                log("Top follows data: {0}".format(json.dumps(data)))
                return data
            else:
                log("Get top follows failed with status: {0}".format(response.status_code))
                log("Response content: {0}".format(response.text))
                return []
        except Exception as e:
            log("Get top follows error: {0}".format(str(e)), xbmc.LOGERROR)
            return []

    def remove_from_favorite(self, linkcode):
        
        if not self.token:
            return False, u"Chưa đăng nhập"
            
        url = "{0}{1}".format(self.base_url, API_CONFIG['CHANGE_FAVORITE'])
        headers = {
            'User-Agent': self.user_agent,
            'Cookie': 'session_id={0}'.format(self.session_id)
        }
        
        data = {
            "items": [linkcode],
            "status": 0,
            "token": self.token
        }
        
        try:
            log("Removing from favorite: {0}".format(linkcode))
            response = self.session.post(url, headers=headers, json=data, verify=APP_CONFIG['VERIFY_SSL'])
            log("Remove favorite response: {0}".format(response.status_code))
            
            if response.status_code == 200:
                return True, u"Đã xóa khỏi yêu thích"
            elif response.status_code == 404:
                return False, u"Không tìm thấy file/folder"
            elif response.status_code == 409:
                return False, u"File/folder không nằm trong danh sách yêu thích"
            else:
                return False, u"Lỗi không xác định (Mã lỗi: {0})".format(response.status_code)
            
        except Exception as e:
            log("Remove favorite error: {0}".format(str(e)), xbmc.LOGERROR)
            return False, u"Lỗi kết nối: {0}".format(str(e))

    def get_speed_test_files(self):
        
        if not self.token:
            return []

        folder_url = 'https://www.fshare.vn/folder/29VCTVL27KXT'
        
        url = "{0}{1}".format(self.base_url, API_CONFIG['GET_FOLDER_LIST'])
        headers = {
            'User-Agent': self.user_agent,
            'Cookie': 'session_id={0}'.format(self.session_id)
        }
        
        data = {
            "token": self.token,
            "url": folder_url,
            "dirOnly": 0,
            "pageIndex": 0,
            "limit": 60
        }
        
        try:
            response = self.session.post(url, headers=headers, json=data, verify=APP_CONFIG['VERIFY_SSL'])
            if response.status_code == 200:
                return response.json()
            return []
        except:
            return []

    def get_public_ip_info(self):
        
        try:
            response = requests.get('http://ip-api.com/json/')
            if response.status_code == 200:
                data = response.json()
                return data.get('query'), data.get('isp')
        except:
            pass
        return None, None

    def recommend_quality(self, speed):
        
        if speed >= 100:
            return "ISO 8K UHD"
        elif speed >= 50:
            return "Video 4K UHD" 
        elif speed >= 35:
            return "Bluray 4K"
        elif speed >= 25:
            return "Bluray 1080p"
        elif speed >= 20:
            return "Video 1440p QHD"
        elif speed >= 10:
            return "Video 1080p FHD"
        elif speed >= 5:
            return "Video 720p HD"
        elif speed >= 3:
            return "480p SD"
        else:
            return "360p SD"

    def search_files(self, query):

        query = query.replace("\n", "").replace(".", " ")
        query = query.replace('&ref=ref', '')
        query = urllib.quote_plus(query)  # Dùng urllib.quote_plus thay vì urllib.parse.quote_plus cho Python 2.7
        
        api_url = 'https://api.timfshare.com/v1/string-query-search?query=' + query
        
        headers = {
            'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
            'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'
        }

        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = requests.post(api_url, headers=headers, timeout=10)
                response.raise_for_status()
                return response.json().get('data', [])
            except Exception as e:
                log("Search error (attempt {0}): {1}".format(attempt + 1, str(e)), xbmc.LOGERROR)
                if attempt == max_retries - 1:
                    return []
                xbmc.sleep(2000)  # Chờ 2 giây trước khi thử lại

    def expand_shortened_url(self, short_id, host):
        
        try:

            xbmc.executebuiltin('Notification(%s,%s,2000,%s)' % (
                'Đang xử lý',
                'Đang sử dụng dịch vụ ' + host,
                xbmcaddon.Addon().getAddonInfo('icon')
            ))

            if host == 'tinyurl.com':
                url = 'https://tinyurl.com/' + short_id
            elif host == 'bitly.com':
                url = 'https://bit.ly/' + short_id
            elif host == 'cutt.ly':
                url = 'https://cutt.ly/' + short_id
            elif host == 'tiny.cc':
                url = 'https://tiny.cc/' + short_id
            elif host == 'bom.so':
                url = 'https://bom.so/' + short_id
            elif host == 't.ly':
                url = 'https://t.ly/' + short_id
            elif host == 'gg.gg':
                url = 'http://gg.gg/' + short_id  # Dùng http cho gg.gg
            else:
                log("Unsupported URL shortener: {0}".format(host), xbmc.LOGERROR)
                return None
            
            log("Processing shortened URL: {0}".format(url))

            headers = {
                'authority': host,
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.134 Safari/537.36'
            }

            try:
                response = requests.get(url, headers=headers, allow_redirects=True)
                log("Response status code: {0}".format(response.status_code))
                
                if response.status_code != 200:
                    log("Failed to get final URL. Status code: {0}".format(response.status_code), xbmc.LOGERROR)
                    xbmc.executebuiltin('Notification(%s,%s,2000,%s)' % (
                        'Lỗi',
                        'Không thể lấy được link từ ' + host,
                        xbmcaddon.Addon().getAddonInfo('icon')
                    ))
                    return None
                    
                final_url = response.url
                log("Final URL: {0}".format(final_url))

                if 'fshare.vn' in final_url:

                    if '?token=' in final_url:
                        original_url = final_url
                        final_url = final_url.split('?token=')[0]
                        log("Removed token from URL: {0} -> {1}".format(original_url, final_url))
                    return final_url

                elif 'docs.google.com' in final_url:
                    log("Google Sheet URL detected: {0}".format(final_url))
                    return final_url

                else:
                    log("Invalid URL type: {0}".format(final_url), xbmc.LOGWARNING)
                    xbmc.executebuiltin('Notification(%s,%s,2000,%s)' % (
                        'Lỗi',
                        'Link không hợp lệ (không phải Fshare hoặc Google Sheet)',
                        xbmcaddon.Addon().getAddonInfo('icon')
                    ))
                    return None
                    
            except requests.exceptions.ConnectionError:
                log("Connection error to {0}".format(host), xbmc.LOGERROR)
                xbmc.executebuiltin('Notification(%s,%s,2000,%s)' % (
                    'Lỗi',
                    'Không thể kết nối tới ' + host,
                    xbmcaddon.Addon().getAddonInfo('icon')
                ))
                return None
            
            except requests.exceptions.Timeout:
                log("Timeout connecting to {0}".format(host), xbmc.LOGERROR)
                xbmc.executebuiltin('Notification(%s,%s,2000,%s)' % (
                    'Lỗi',
                    'Kết nối tới ' + host + ' quá thời gian',
                    xbmcaddon.Addon().getAddonInfo('icon')
                ))
                return None
            
        except Exception as e:
            log("Expand URL error: {0}".format(str(e)), xbmc.LOGERROR)
            xbmc.executebuiltin('Notification(%s,%s,2000,%s)' % (
                'Lỗi',
                'Lỗi xử lý link: ' + str(e),
                xbmcaddon.Addon().getAddonInfo('icon')
            ))
            return None

    def get_file_info(self, url):
        
        try:
            if not self.token:
                return None, None, None
            
            data = {
                "token": self.token,
                "url": url
            }
            headers = {
                'User-Agent': self.user_agent,
                'Cookie': 'session_id=' + self.session_id
            }
            
            response = requests.post(
                'https://api.fshare.vn/api/fileops/get',
                headers=headers,
                json=data,
                verify=APP_CONFIG['VERIFY_SSL']
            )
            
            if response.status_code == 200:
                result = response.json()
                return (
                    result.get('name', ''),
                    result.get('file_type', ''),
                    result.get('size', 0)
                )
            else:
                log("Get file info failed. Status code: {0}".format(response.status_code), xbmc.LOGERROR)
                return None, None, None
            
        except Exception as e:
            log("Get file info error: {0}".format(str(e)), xbmc.LOGERROR)
            return None, None, None
