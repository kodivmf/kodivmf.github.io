# -*- coding: utf-8 -*-
import os
import sys
import time
import json
import random
import requests

addon_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, addon_dir)

import urllib
import urlparse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from resources.lib.fshare import Fshare

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]
args = urlparse.parse_qs(sys.argv[2][1:])
fshare = Fshare()

reload(sys)
sys.setdefaultencoding('utf-8')

MEDIA_PATH = os.path.join(addon_dir, 'resources', 'media')
LOGO_PATH = os.path.join(MEDIA_PATH, 'logo.png')
FANART_PATH = os.path.join(MEDIA_PATH, 'fanart.png')
FSHARE_ICON = os.path.join(MEDIA_PATH, 'fshare.png')
NEXT_ICON = os.path.join(MEDIA_PATH, 'next.png')

SEARCH_ICON = os.path.join(MEDIA_PATH, 'search.png')  
INPUT_ICON = os.path.join(MEDIA_PATH, 'input.png')
MYFILES_ICON = os.path.join(MEDIA_PATH, 'myfiles.png')
FAVORITE_ICON = os.path.join(MEDIA_PATH, 'favorite.png')
TOPFILES_ICON = os.path.join(MEDIA_PATH, 'topfiles.png')
TOPFOLLOW_ICON = os.path.join(MEDIA_PATH, 'topfollow.png')
SPEEDTEST_ICON = os.path.join(MEDIA_PATH, 'speedtest.png')
ACCOUNT_ICON = os.path.join(MEDIA_PATH, 'account.png')
SETTINGS_ICON = os.path.join(MEDIA_PATH, 'settings.png')

USER_ICON = os.path.join(MEDIA_PATH, 'user.png')

INFO_ICON = os.path.join(MEDIA_PATH, 'info.png')

GSHEET_ICON = os.path.join(MEDIA_PATH, 'gsheet.png')

HISTORY_ICON = os.path.join(MEDIA_PATH, 'history.png')

FILES_ICON = os.path.join(MEDIA_PATH, 'files.png')

CAPNHAT_ICON = os.path.join(MEDIA_PATH, 'capnhat.png')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_dir(name, mode, iconimage="DefaultFolder.png", isfolder=True, description=""):
    url = build_url({'mode': mode})
    li = xbmcgui.ListItem(name)

    if iconimage == "DefaultFolder.png":
        iconimage = MENU_ICON
        
    li.setArt({
        'icon': iconimage,
        'thumb': iconimage,
        'fanart': FANART_PATH
    })
    
    li.setInfo('video', {'Title': name, 'Plot': description})
    if not isfolder:
        li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isfolder)

def show_notification(message):
    message = message.encode('utf-8')
    xbmcgui.Dialog().notification(u'Fshare'.encode('utf-8'), message, xbmcgui.NOTIFICATION_INFO, 5000)

def show_main_menu():
    
    add_dir(u"Tìm kiếm".encode('utf-8'), "search", SEARCH_ICON)
    add_dir(u"Play Code".encode('utf-8'), "input", INPUT_ICON)
    add_dir(u"Lịch sử xem".encode('utf-8'), "play_history", HISTORY_ICON)
    add_dir(u"Yêu thích".encode('utf-8'), "favourites", FAVORITE_ICON)

    advertisements = get_advertisements()
    for adv in advertisements:
        try:

            expired_date = adv.get('expiredDate', '2099-12-31')
            current_date = time.strftime('%Y-%m-%d')
            
            if current_date <= expired_date:

                name = adv.get('name', '')
                thumb = adv.get('thumb', '')
                pilot = adv.get('pilot', '')
                path = adv.get('path', '')
                
                if name and path:

                    name_encoded = name.encode('utf-8') if isinstance(name, unicode) else name.decode('utf-8').encode('utf-8')
                    pilot_encoded = pilot.encode('utf-8') if isinstance(pilot, unicode) else pilot.decode('utf-8').encode('utf-8')

                    li = xbmcgui.ListItem(name_encoded)
                    li.setInfo('video', {'Title': name_encoded, 'Plot': pilot_encoded})

                    li.setArt({
                        'icon': thumb,
                        'thumb': thumb,
                        'fanart': FANART_PATH
                    })

                    url = build_url({
                        'mode': 'show_advertisement',
                        'path': path, 
                        'title': name_encoded
                    })
                    
                    xbmcplugin.addDirectoryItem(
                        handle=addon_handle,
                        url=url,
                        listitem=li,
                        isFolder=False
                    )
        except Exception as e:
            log("Error processing advertisement: {}".format(str(e)), xbmc.LOGERROR)
            continue

    add_dir(u"Top Follows".encode('utf-8'), "top_follows", TOPFOLLOW_ICON)
    add_dir(u"My files".encode('utf-8'), "my_files", MYFILES_ICON)
    add_dir(u"Đo tốc độ Fshare".encode('utf-8'), "speed_test", SPEEDTEST_ICON)
    add_dir(u"Cài đặt".encode('utf-8'), "settings_menu", SETTINGS_ICON)
    xbmcplugin.endOfDirectory(addon_handle)
    
def log(msg, level=xbmc.LOGNOTICE):
    xbmc.log("FSHARE: %s" % msg, level)

def check_account_status():
    
    try:
        account_info = fshare.get_user_info()
        if account_info:
            account_type = account_info.get('account_type', '')
            expire_vip = account_info.get('expire_vip', '')
            
            if expire_vip:
                try:

                    expire_timestamp = int(expire_vip)
                    current_timestamp = time.time()

                    days_left = int((expire_timestamp - current_timestamp) / (24 * 3600))
                    
                    if days_left <= 3 and days_left > 0:

                        xbmcgui.Dialog().ok(
                            u'Thông báo tài khoản'.encode('utf-8'),
                            u'Tài khoản VIP của bạn sẽ hết hạn trong {0} ngày!\n\n[COLOR yellow]Ủng hộ addon và mua tài khoản Fshare VIP[/COLOR]\nLiên hệ Zalo: 0915134560'.format(days_left).encode('utf-8')
                        )
                    elif days_left <= 0:

                        xbmcgui.Dialog().ok(
                            u'Thông báo tài khoản'.encode('utf-8'),
                            u'Tài khoản VIP của bạn đã hết hạn!\n\n[COLOR yellow]Ủng hộ addon và mua tài khoản Fshare VIP[/COLOR]\nLiên hệ Zalo: 0915134560'.encode('utf-8')
                        )
                except:
                    pass
            
            if account_type.lower() == 'member':

                if addon.getSetting('member_notified') != 'true':
                    xbmcgui.Dialog().ok(
                        u'Thông báo tài khoản'.encode('utf-8'),
                        u'Bạn đang sử dụng tài khoản Member.\nĐể có trải nghiệm tốt nhất, hãy nâng cấp lên tài khoản VIP!\n\n[COLOR yellow]Ủng hộ addon và mua tài khoản Fshare VIP[/COLOR]\nLiên hệ Zalo: 0915134560'.encode('utf-8')
                    )
                    addon.setSetting('member_notified', 'true')
                    
    except Exception as e:
        log("Check account status error: " + str(e))

def login():
    username = addon.getSetting('username')
    password = addon.getSetting('password')
    
    if not username or not password:
        xbmcgui.Dialog().ok(
            u'Lỗi đăng nhập'.encode('utf-8'), 
            u'Vui lòng nhập username và password trong phần cài đặt\n\n[COLOR yellow]Ủng hộ addon và mua tài khoản Fshare VIP[/COLOR]\nLiên hệ Zalo: 0915134560'.encode('utf-8')
        )
        addon.openSettings()
        return False

    token = addon.getSetting('tokenfshare')
    session_id = addon.getSetting('sessionfshare')
    timelog = addon.getSetting('timelog')

    if token and session_id and timelog:
        current_time = int(time.time())
        if current_time - int(timelog) < 7200:  # 120 phút = 7200s
            fshare.token = token
            fshare.session_id = session_id

            check_account_status()
            return True

    result = fshare.login(username, password)
    if len(result) == 4:  # Đăng nhập thành công
        success, token, session_id, timelog = result

        addon.setSetting('tokenfshare', token)
        addon.setSetting('sessionfshare', session_id) 
        addon.setSetting('timelog', timelog)
        show_notification(u'Đăng nhập thành công: {0}'.format(username).encode('utf-8'))

        check_account_status()
        return True
    else:  # Đăng nhập thất bại
        success, token, session_id, timelog, message = result
        xbmcgui.Dialog().ok(
            u'Lỗi đăng nhập'.encode('utf-8'),
            message.encode('utf-8')
        )
        addon.openSettings()
        return False

def get_input_history():
    
    if addon.getSetting('save_input_history') != 'true':
        return []
        
    history = addon.getSetting('input_history')
    return history.split('||') if history else []  # Dùng || để phân tách các entry

def add_to_input_history(name, final_url):
    
    if addon.getSetting('save_input_history') != 'true':
        return
        
    history = get_input_history()
    entry = '{0}|{1}'.format(name, final_url)  # Lưu tên và URL

    history = [h for h in history if h.split('|')[1] != final_url]

    history.insert(0, entry)

    max_items = int(addon.getSetting('max_input_history'))
    history = history[:max_items]

    addon.setSetting('input_history', '||'.join(history))

def show_textbox(heading, text):
    
    class TextBox():
        WINDOW = 10147
        CONTROL_LABEL = 1
        CONTROL_TEXTBOX = 5

        def __init__(self, *args, **kwargs):
            xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, ))
            self.win = xbmcgui.Window(self.WINDOW)
            xbmc.sleep(500)
            self.setControls()
            self.win.setProperty('resolution', '1920x1080')

        def setControls(self):

            if isinstance(heading, str):
                try:
                    heading_decoded = heading.decode('utf-8')
                except UnicodeDecodeError:
                    heading_decoded = heading
            else:
                heading_decoded = heading
                
            if isinstance(text, str):
                try:
                    text_decoded = text.decode('utf-8')
                except UnicodeDecodeError:
                    text_decoded = text
            else:
                text_decoded = text
                
            self.win.getControl(self.CONTROL_LABEL).setLabel(heading_decoded)
            self.win.getControl(self.CONTROL_TEXTBOX).setText(text_decoded)
            return

    TextBox()
    while xbmc.getCondVisibility('Window.IsVisible(10147)'):
        time.sleep(.5)
def show_input_guide():
    
    if addon.getSetting('show_input_guide') == 'true':
        guide_text = u

        show_textbox(u'Hướng dẫn nhập Play Code'.encode('utf-8'), guide_text.encode('utf-8'))

        if xbmcgui.Dialog().yesno(
            u'Hướng dẫn nhập Play Code'.encode('utf-8'),
            u'Bạn có muốn hiện lại hướng dẫn này vào lần sau không?\nBạn có thể bật/tắt hướng dẫn này trong phần cài đặt addon.'.encode('utf-8'),
            nolabel=u'Không hiện lại'.encode('utf-8'),
            yeslabel=u'Hiện lại'.encode('utf-8')
        ):
            addon.setSetting('show_input_guide', 'true')
        else:
            addon.setSetting('show_input_guide', 'false')

def show_input_menu():

    show_input_guide()

    add_dir(u"[COLOR yellow]Nhập Code/Id mới[/COLOR]".encode('utf-8'), "new_input", INPUT_ICON)

    li = xbmcgui.ListItem(u"Top code - Góc Chia Sẻ".encode('utf-8'))
    li.setArt({
        'icon': os.path.join(MEDIA_PATH, 'share.png'),
        'thumb': os.path.join(MEDIA_PATH, 'share.png'),
        'fanart': FANART_PATH
    })
    li.setInfo('video', {'Title': u"Top code - Góc Chia Sẻ".encode('utf-8')})

    query = {
        'mode': 'process_url',
        'url': 'https://docs.google.com/spreadsheets/d/1yCyQ1ZqIaeEkh5TYiXqPkTkRtrlbWkc6mL5jA2s6VqM/edit?gid=0#gid=0'
    }
    
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url(query),
        listitem=li,
        isFolder=True
    )

    history = get_input_history()
    for entry in history:
        try:
            name, final_url = entry.split('|')

            li = xbmcgui.ListItem(name)

            is_sheet = is_google_sheet_url(final_url)
            icon = GSHEET_ICON if is_sheet else FSHARE_ICON
            
            li.setArt({
                'icon': icon,
                'thumb': icon,
                'fanart': FANART_PATH
            })

            context_menu = [
                (u'[COLOR yellow]Xóa khỏi lịch sử[/COLOR]'.encode('utf-8'),
                 'RunPlugin({0}?mode=remove_input_history&url={1})'.format(
                     sys.argv[0], urllib.quote_plus(final_url))),
                (u'[COLOR yellow]Xóa tất cả lịch sử[/COLOR]'.encode('utf-8'),
                 'RunPlugin({0}?mode=clear_input_history)'.format(sys.argv[0])),
                (u'[COLOR lime]Tải xuống[/COLOR]'.encode('utf-8'),
                 'RunPlugin({0}?mode=download&url={1})'.format(
                     sys.argv[0], urllib.quote_plus(final_url))),
                (u'[COLOR lime]Thêm vào yêu thích[/COLOR]'.encode('utf-8'),
                 'RunPlugin({0}?mode=add_favorite&linkcode={1})'.format(
                     sys.argv[0], urllib.quote_plus(final_url.split('/')[-1])))
            ]
            
            li.addContextMenuItems(context_menu)

            query = {
                'mode': 'process_url' if is_sheet else ('folder' if '/folder/' in final_url else 'play'),
                'url': final_url
            }
            
            xbmcplugin.addDirectoryItem(
                handle=addon_handle,
                url=build_url(query),
                listitem=li,
                isFolder=True if is_sheet or '/folder/' in final_url else False
            )
        except:
            continue
    
    xbmcplugin.endOfDirectory(addon_handle)

def remove_from_input_history(final_url):
    
    history = get_input_history()

    history = [h for h in history if h.split('|')[1] != final_url]
    addon.setSetting('input_history', '||'.join(history))
    xbmc.executebuiltin('Container.Refresh')

def is_google_sheet_url(url):
    
    return 'docs.google.com/spreadsheets' in url

def show_sheet_items(items):
    
    if not items:
        show_notification(u'Không có dữ liệu từ Google Sheet'.encode('utf-8'))
        return
        
    for item in items:
        name = item['name']
        link = item['link']
        poster = item.get('poster', '')  # Sử dụng get() để tránh lỗi nếu không có poster
        pilot = item.get('pilot', '')    # Sử dụng get() để tránh lỗi nếu không có pilot
        
        li = xbmcgui.ListItem(name)

        info = {'Title': name}
        if pilot:  # Chỉ thêm pilot nếu có
            info['Plot'] = pilot
        li.setInfo('video', info)

        li.setArt({
            'icon': GSHEET_ICON,
            'thumb': poster if poster else GSHEET_ICON,
            'fanart': FANART_PATH
        })

        query = {
            'mode': 'process_url',
            'url': link
        }
        
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url(query),
            listitem=li,
            isFolder=True
        )
        
    xbmcplugin.endOfDirectory(addon_handle)

def process_fshare_url(url):
    
    try:
        if is_google_sheet_url(url):

            from resources.lib.gsheet import get_sheet_data
            items = get_sheet_data(url)
            show_sheet_items(items)
        else:

            if '/file/' in url:

                name, file_type, size = fshare.get_file_info(url)
                if not name:
                    show_notification(u'Không thể lấy thông tin file'.encode('utf-8'))
                    return

                size_str = format_size(float(size))

                display_name = u"{0} [COLOR gray][{1}][/COLOR]".format(
                    name, size_str
                ).encode('utf-8')

                li = xbmcgui.ListItem(display_name)
                li.setInfo('video', {
                    'Title': name,
                    'Size': size
                })

                li.setProperty('IsPlayable', 'true')

                context_menu = [
                    (u'[COLOR yellow]Xóa khỏi lịch sử[/COLOR]'.encode('utf-8'),
                     'RunPlugin({0}?mode=remove_input_history&url={1})'.format(
                         sys.argv[0], urllib.quote_plus(url))),
                    (u'[COLOR yellow]Xóa tất cả lịch sử[/COLOR]'.encode('utf-8'),
                     'RunPlugin({0}?mode=clear_input_history)'.format(sys.argv[0])),
                    (u'[COLOR lime]Tải xuống[/COLOR]'.encode('utf-8'),
                     'RunPlugin({0}?mode=download&url={1})'.format(
                         sys.argv[0], urllib.quote_plus(url))),
                    (u'[COLOR lime]Thêm vào yêu thích[/COLOR]'.encode('utf-8'),
                     'RunPlugin({0}?mode=add_favorite&linkcode={1})'.format(
                         sys.argv[0], urllib.quote_plus(url.split('/')[-1])))
                ]
                li.addContextMenuItems(context_menu)

                play_url = build_url({
                    'mode': 'play',
                    'url': url
                })

                li.setArt({
                    'icon': FSHARE_ICON,
                    'thumb': FSHARE_ICON,
                    'fanart': FANART_PATH
                })

                xbmcplugin.addDirectoryItem(
                    handle=addon_handle,
                    url=play_url,
                    listitem=li,
                    isFolder=False
                )
                
                xbmcplugin.endOfDirectory(addon_handle)
                
            elif '/folder/' in url:

                log("Getting folder content from URL: {0}".format(url))
                files, has_next = fshare.get_folder_list(url)
                
                if files is None:
                    log("Failed to get folder content - files is None", xbmc.LOGERROR)
                    show_notification(u'Không thể lấy nội dung thư mục'.encode('utf-8'))
                    return
                    
                if not isinstance(files, list):
                    log("Invalid folder content type: {0}".format(type(files)), xbmc.LOGERROR)
                    show_notification(u'Dữ liệu thư mục không hợp lệ'.encode('utf-8'))
                    return
                    
                if files:
                    log("Got {0} files, showing list...".format(len(files)))
                    show_files(files, 'folder', url, 0, has_next)
                else:
                    log("Empty folder content", xbmc.LOGWARNING)
                    show_notification(u'Thư mục trống'.encode('utf-8'))
                    xbmcplugin.endOfDirectory(addon_handle)
            else:
                log("Invalid Fshare URL format: {0}".format(url), xbmc.LOGERROR)
                show_notification(u'Link Fshare không hợp lệ'.encode('utf-8'))
                
    except Exception as e:
        log("Process URL error: {0}".format(str(e)), xbmc.LOGERROR)
        show_notification(u'Lỗi xử lý link'.encode('utf-8'))

def input_url():
    
    keyboard = xbmc.Keyboard('', u'Nhập ID rút gọn'.encode('utf-8'))
    keyboard.doModal()
    if keyboard.isConfirmed():
        short_id = keyboard.getText()
        if short_id:

            host = addon.getSetting('shorten_host')

            final_url = fshare.expand_shortened_url(short_id, host)
            if final_url:
                add_to_input_history(short_id, final_url)
                if 'fshare.vn' in final_url:

                    process_fshare_url(final_url)
                    return None  # Trả về None vì đã xử lý xong
                return final_url  # Trả về URL khác (vd: Google Sheet)
            else:
                show_notification(u'Không thể lấy link gốc'.encode('utf-8'))
    return None

def format_size(size):
    
    try:
        size = float(size)
        if size < 1024:
            return "{:.0f} B".format(size)
        elif size < 1024**2:
            return "{:.1f} KB".format(size/1024)
        elif size < 1024**3:
            return "{:.1f} MB".format(size/(1024**2))
        else:
            return "{:.2f} GB".format(size/(1024**3))
    except:
        return "0 B"

def format_speed(speed):
    
    return format_size(speed) + "/s"

def format_time(seconds):
    
    if seconds < 60:
        return "{:.0f} giây".format(seconds)
    elif seconds < 3600:
        return "{:.0f} phút {:.0f} giây".format(seconds // 60, seconds % 60)
    else:
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        return "{:.0f} giờ {:.0f} phút".format(hours, minutes)

def download_file(url):

    download_path = addon.getSetting('download_path')
    if not download_path:

        if xbmcgui.Dialog().yesno(
            u'Chưa cấu hình thư mục tải xuống'.encode('utf-8'),
            u'Bạn cần thiết lập thư mục tải xuống trong phần cài đặt.'.encode('utf-8'),
            u'Bạn có muốn thiết lập ngay không?'.encode('utf-8')
        ):
            addon.openSettings()
            download_path = addon.getSetting('download_path')
            if not download_path:
                return
        else:
            return

    dialog = xbmcgui.DialogProgress()
    dialog.create(u'Đang tải xuống'.encode('utf-8'))

    def progress_callback(downloaded, total, start_time):
        if dialog.iscanceled():
            return False

        percent = int(100 * downloaded / total) if total else 0
        elapsed_time = time.time() - start_time
        speed = downloaded / elapsed_time if elapsed_time > 0 else 0

        if speed > 0:
            remaining_bytes = total - downloaded
            eta = remaining_bytes / speed
        else:
            eta = 0

        dialog.update(
            percent,
            u"Tải xuống: {0}/{1}".format(
                format_size(downloaded), format_size(total)
            ).encode('utf-8'),
            u"Tốc độ: {0}".format(format_speed(speed)).encode('utf-8'),
            u"Thời gian còn lại: {0}".format(format_time(eta)).encode('utf-8')
        )
        return True

    success, result = fshare.download_file(url, download_path, progress_callback)
    dialog.close()

    if success:

        if xbmcgui.Dialog().yesno(
            u'Tải xuống hoàn tất'.encode('utf-8'),
            u'Bạn có muốn phát file ngay không?'.encode('utf-8')
        ):
            xbmc.Player().play(result)
    else:
        show_notification(u'Lỗi khi tải xuống: {0}'.format(result).encode('utf-8'))

def show_files(files, mode, current_path='/', page_index=0, has_next=False):
    
    try:
        for file in files:
            try:

                name = file.get('name', '')
                if isinstance(name, unicode):
                    name = name.encode('utf-8')
                elif isinstance(name, str):
                    name = name.decode('utf-8').encode('utf-8')
                    
                linkcode = file.get('linkcode', '')
                is_folder = file.get('type') == '0'  # type 0 là folder, 1 là file

                if is_folder:
                    url = 'https://www.fshare.vn/folder/' + linkcode
                else:
                    url = 'https://www.fshare.vn/file/' + linkcode

                li = xbmcgui.ListItem(name)

                li.setInfo('video', {
                    'Title': name,
                    'Size': int(file.get('size', 0))
                })

                li.setArt({
                    'icon': FSHARE_ICON,
                    'thumb': FSHARE_ICON,
                    'fanart': FANART_PATH
                })
                
                if not is_folder:
                    li.setProperty('IsPlayable', 'true')

                context_menu = []
                
                if not is_folder:
                    context_menu.extend([
                        (u'[COLOR yellow]Xóa khỏi lịch sử[/COLOR]'.encode('utf-8'),
                         'RunPlugin({0}?mode=remove_input_history&url={1})'.format(
                             sys.argv[0], urllib.quote_plus(url))),
                        (u'[COLOR yellow]Xóa tất cả lịch sử[/COLOR]'.encode('utf-8'),
                         'RunPlugin({0}?mode=clear_input_history)'.format(sys.argv[0])),
                        (u'[COLOR lime]Tải xuống[/COLOR]'.encode('utf-8'),
                         'RunPlugin({0}?mode=download&url={1})'.format(
                             sys.argv[0], urllib.quote_plus(url))),
                        (u'[COLOR lime]Thêm vào yêu thích[/COLOR]'.encode('utf-8'),
                         'RunPlugin({0}?mode=add_favorite&linkcode={1})'.format(
                             sys.argv[0], urllib.quote_plus(linkcode)))
                    ])

                if context_menu:
                    li.addContextMenuItems(context_menu)

                query = {
                    'mode': 'play' if not is_folder else 'folder',
                    'url': url
                }
                
                xbmcplugin.addDirectoryItem(
                    handle=addon_handle,
                    url=build_url(query),
                    listitem=li,
                    isFolder=is_folder
                )
                
            except Exception as e:
                log("Error processing file: {0}".format(str(e)), xbmc.LOGERROR)
                continue

        if mode in ['folder', 'my_files', 'favourites'] and has_next:
            next_page = page_index + 1
            next_label = u'Trang tiếp theo >>'.encode('utf-8')
            
            query = {
                'mode': mode,
                'page': next_page
            }
            
            if mode == 'folder':
                query['url'] = current_path
            elif mode == 'my_files':
                query['path'] = current_path
                
            li = xbmcgui.ListItem(next_label)
            li.setArt({
                'icon': NEXT_ICON,
                'thumb': NEXT_ICON,
                'fanart': FANART_PATH
            })
            
            xbmcplugin.addDirectoryItem(
                handle=addon_handle,
                url=build_url(query),
                listitem=li,
                isFolder=True
            )
            
        xbmcplugin.endOfDirectory(addon_handle)
        
    except Exception as e:
        log("Show files error: {0}".format(str(e)), xbmc.LOGERROR)
        show_notification(u'Lỗi hiển thị danh sách'.encode('utf-8'))

def get_advertisements():
    
    try:
        url = "https://fshare.vip/adv/qc.json"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:

            data = json.loads(response.text)
            return data
        else:
            log("Failed to get advertisements. Status code: {}".format(response.status_code), xbmc.LOGERROR)
            return []
    except Exception as e:
        log("Error getting advertisements: {}".format(str(e)), xbmc.LOGERROR)
        return []

def show_advertisement_content(path, title):
    
    try:

        if path.endswith('.txt'):

            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
            }
            response = requests.get(path, headers=headers, timeout=10)
            
            if response.status_code == 200:

                content = response.content  # Dùng .content thay vì .text để giữ nguyên byte data

                try:

                    content_decoded = content.decode('utf-8')
                except UnicodeDecodeError:
                    try:

                        content_decoded = content.decode('cp1258')
                    except UnicodeDecodeError:

                        content_decoded = content.decode('latin-1')

                if isinstance(title, str):
                    try:
                        title = title.decode('utf-8')
                    except UnicodeDecodeError:
                        pass
                        
                show_textbox(title, content_decoded)
            else:
                show_notification(u'Không thể tải nội dung'.encode('utf-8'))
                
        elif path.endswith(('.jpg', '.jpeg', '.png', '.gif')):

            image_dialog = xbmcgui.Dialog()
            image_dialog.notification(title, u'Đang tải ảnh...'.encode('utf-8'), xbmcgui.NOTIFICATION_INFO, 2000)

            xbmc.executebuiltin('ShowPicture({})'.format(path))
            
        else:

            if 'fshare.vn' in path:
                process_fshare_url(path)
            else:
                show_notification(u'Loại file không được hỗ trợ'.encode('utf-8'))
                
    except Exception as e:
        log("Error showing advertisement content: {}".format(str(e)), xbmc.LOGERROR)
        show_notification(u'Lỗi hiển thị nội dung'.encode('utf-8'))
        
def show_top_files():
    
    files = fshare.get_top_files()
    if not files:
        show_notification(u'Không thể lấy danh sách top files tìm kiếm'.encode('utf-8'))
        return
        
    try:
        for file in files:
            try:

                name = file.get('name', '')
                if isinstance(name, unicode):
                    name = name.encode('utf-8')
                elif isinstance(name, str):
                    name = name.decode('utf-8').encode('utf-8')
                    
                linkcode = file.get('linkcode', '')
                size = float(file.get('size', 0))

                url = 'https://www.fshare.vn/file/' + linkcode

                size_str = format_size(size)

                display_name = u"{0} [COLOR gray][{1}][/COLOR]".format(
                    name, size_str
                ).encode('utf-8')

                li = xbmcgui.ListItem(display_name)
                li.setInfo('video', {
                    'Title': name,
                    'Size': size
                })

                li.setProperty('IsPlayable', 'true')

                context_menu = [
                    (u'[COLOR yellow]Xóa khỏi lịch sử[/COLOR]'.encode('utf-8'),
                     'RunPlugin({0}?mode=remove_input_history&url={1})'.format(
                         sys.argv[0], urllib.quote_plus(url))),
                    (u'[COLOR yellow]Xóa tất cả lịch sử[/COLOR]'.encode('utf-8'),
                     'RunPlugin({0}?mode=clear_input_history)'.format(sys.argv[0])),
                    (u'[COLOR lime]Tải xuống[/COLOR]'.encode('utf-8'),
                     'RunPlugin({0}?mode=download&url={1})'.format(
                         sys.argv[0], urllib.quote_plus(url))),
                    (u'[COLOR lime]Thêm vào yêu thích[/COLOR]'.encode('utf-8'),
                     'RunPlugin({0}?mode=add_favorite&linkcode={1})'.format(
                         sys.argv[0], urllib.quote_plus(linkcode)))
                ]
                li.addContextMenuItems(context_menu)

                query = {
                    'mode': 'play',
                    'url': url
                }
                
                xbmcplugin.addDirectoryItem(
                    handle=addon_handle,
                    url=build_url(query),
                    listitem=li,
                    isFolder=False
                )
                
            except Exception as e:
                log("Error processing top file: {0}".format(str(e)), xbmc.LOGERROR)
                continue
                
        xbmcplugin.endOfDirectory(addon_handle)
        
    except Exception as e:
        log("Error showing top files: {0}".format(str(e)), xbmc.LOGERROR)
        show_notification(u'Lỗi hiển thị danh sách top files tìm kiếm'.encode('utf-8'))

def play_video(url):
    
    try:
        url = url.split('?share=')[0] + '?share=8805984' if '?share=' in url else url + '?share=8805984'
        progress = xbmcgui.DialogProgress()
        progress.create(u'Đang chuẩn bị phát video'.encode('utf-8'), 
                       u'Đang lấy link phát...'.encode('utf-8'))
        
        log("Getting direct link for: {0}".format(url))
        direct_url = fshare.get_direct_link(url)

        progress.close()
        
        if direct_url:

            name, file_type, size = fshare.get_file_info(url)
            if name and size:
                add_to_play_history(name, url, size)
            
            log("Playing direct URL: {0}".format(direct_url))
            play_item = xbmcgui.ListItem(path=direct_url)
            play_item.setProperty('IsPlayable', 'true')
            play_item.setMimeType('video/mp4')
            play_item.setContentLookup(False)

            if addon_handle >= 0:
                xbmcplugin.setResolvedUrl(addon_handle, True, play_item)
            else:

                xbmc.Player().play(direct_url, play_item)
        else:
            log("Failed to get direct link", xbmc.LOGERROR)
            show_notification(u'Không thể lấy link phát video'.encode('utf-8'))
            if addon_handle >= 0:
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            
    except Exception as e:

        if 'progress' in locals():
            progress.close()
        log("Play video error: {0}".format(str(e)), xbmc.LOGERROR)
        show_notification(u'Lỗi phát video'.encode('utf-8'))
        if addon_handle >= 0:
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def show_account_info():
    info = fshare.get_user_info()
    if info:

        email = info.get('email', '')
        account_type = info.get('account_type', '')
        expire_vip = int(info.get('expire_vip', 0))
        traffic_used = int(info.get('traffic_used', 0))
        webspace_used = int(info.get('webspace_used', 0))
        webspace = int(info.get('webspace', 0))

        traffic_used_gb = traffic_used / (1024 ** 3)
        webspace_used_gb = webspace_used / (1024 ** 3)
        webspace_gb = webspace / (1024 ** 3)

        expire_date = time.strftime('%d/%m/%Y', time.localtime(expire_vip))

        message = u"• [COLOR yellow]Email & Loại tài khoản:[/COLOR] {0} | {1}\n".format(email, account_type)
        message += u"• [COLOR yellow]Hết hạn VIP:[/COLOR] {0}\n".format(expire_date)
        message += u"• [COLOR yellow]Lưu lượng đã dùng:[/COLOR] {0:.2f} GB\n".format(traffic_used_gb)
        message += u"• [COLOR yellow]Dung lượng đã dùng:[/COLOR] {0:.2f} GB / {1:.2f} GB".format(
            webspace_used_gb, webspace_gb)

        xbmcgui.Dialog().ok(u"Thông tin tài khoản".encode('utf-8'), message.encode('utf-8'))
    else:
        show_notification(u'Không thể lấy thông tin tài khoản'.encode('utf-8'))

def show_top_follows():
    log("Fetching top follows...")
    follows = fshare.get_top_follows()
    log("Received follows data: {0}".format(len(follows)))
    
    try:
        for item in follows:
            try:

                log("Processing follow item: {0}".format(json.dumps(item)))

                name = item.get('name', '')
                if isinstance(name, unicode):
                    name = name.encode('utf-8')
                elif isinstance(name, str):
                    name = name.decode('utf-8').encode('utf-8')
                    
                linkcode = item.get('linkcode', '')
                followers = item.get('followers', 0)
                
                log("Item info - Name: {0}, Linkcode: {1}, Followers: {2}".format(
                    name, linkcode, followers))

                display_name = u"{0} [COLOR gray][{1:,} follows][/COLOR]".format(
                    name, followers
                ).encode('utf-8')

                url = 'https://www.fshare.vn/folder/' + linkcode

                li = xbmcgui.ListItem(display_name)
                li.setInfo('video', {
                    'Title': name,
                    'Plot': u'{0:,} người theo dõi'.format(followers)
                })

                query = {
                    'mode': 'folder',
                    'url': url,
                    'page': 0
                }
                
                xbmcplugin.addDirectoryItem(
                    handle=addon_handle,
                    url=build_url(query),
                    listitem=li,
                    isFolder=True
                )
                log("Added item to directory: {0}".format(display_name))
                
            except Exception as e:
                log("Error processing follow item: {0}".format(str(e)), xbmc.LOGERROR)
                continue
                
        xbmcplugin.endOfDirectory(addon_handle)
        log("Finished showing top follows")
        
    except Exception as e:
        log("Error showing top follows: {0}".format(str(e)), xbmc.LOGERROR)
        show_notification(u'Lỗi hiển thị danh sách top follows'.encode('utf-8'))

def speed_test():
    
    test_file = os.path.join(xbmc.translatePath('special://home/userdata/'), 'test.zip')

    public_ip, isp = fshare.get_public_ip_info()
    ip_info = u'IP: [COLOR yellow]{}[/COLOR] - {}'.format(
        public_ip or 'Unknown',
        isp or 'Unknown'
    ).encode('utf-8')

    files = fshare.get_speed_test_files()
    if not files:
        show_notification(u'Không thể lấy file test'.encode('utf-8'))
        return

    test_file_url = random.choice([f['furl'] for f in files])

    direct_url = fshare.get_direct_link(test_file_url)
    if not direct_url:
        show_notification(u'Không thể lấy link tải'.encode('utf-8'))
        return

    dialog = xbmcgui.DialogProgress()
    dialog.create(u'Đang đo tốc độ Fshare'.encode('utf-8'))
    
    try:

        response = requests.head(direct_url)
        file_size = int(response.headers.get('content-length', 0))

        if os.path.exists(test_file):
            try:
                os.remove(test_file)
            except:
                pass

        chunk_size = 128 * 1024  # 128KB chunks để tăng tốc độ đọc/ghi
        
        start_time = time.time()
        downloaded = 0
        speeds = []  # Lưu lại các mẫu tốc độ để tính trung bình
        update_interval = 0.5  # Cập nhật UI mỗi 0.5 giây
        last_update = 0
        
        with requests.get(direct_url, stream=True) as r:
            with open(test_file, 'wb') as f:
                for chunk in r.iter_content(chunk_size=chunk_size):
                    if dialog.iscanceled():
                        speed = (downloaded * 8 / (time.time() - start_time)) / (1024 * 1024)
                        xbmcgui.Dialog().ok(
                            u'Đã hủy'.encode('utf-8'),
                            u'Tốc độ đo được: [COLOR yellow]{:.2f} Mbps[/COLOR]'.format(speed).encode('utf-8')
                        )
                        try:
                            os.remove(test_file)
                        except:
                            pass
                        return
                        
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        
                        current_time = time.time()
                        elapsed = current_time - start_time

                        if current_time - last_update >= update_interval:
                            if elapsed > 0:
                                speed = (downloaded * 8 / elapsed) / (1024 * 1024)
                                speeds.append(speed)

                                if len(speeds) > 10:
                                    speeds.pop(0)
                                avg_speed = sum(speeds) / len(speeds)
                                
                                percent = int(100 * downloaded / file_size)
                                eta = (file_size - downloaded) / (downloaded / elapsed) if speed > 0 else 0
                                
                                dialog.update(
                                    percent,
                                    u'Tốc độ hiện tại: [COLOR yellow]{:.2f} Mbps[/COLOR]'.format(avg_speed).encode('utf-8'),
                                    u'Tiến độ: {}%'.format(percent).encode('utf-8'),
                                    u'Thời gian còn lại: {}\n{}'.format(
                                        time.strftime('%H:%M:%S', time.gmtime(eta)),
                                        ip_info
                                    ).encode('utf-8')
                                )
                                last_update = current_time

        final_speed = sum(speeds) / len(speeds) if speeds else 0  # Lấy trung bình của các mẫu
        quality = fshare.recommend_quality(final_speed)
        
        xbmcgui.Dialog().ok(
            u'Kết quả đo tốc độ'.encode('utf-8'),
            ip_info + u'\n' +
            u'Tốc độ đo được: [COLOR yellow]{:.2f} Mbps[/COLOR]\n'.format(final_speed).encode('utf-8') +
            u'Chất lượng video đề xuất: [COLOR yellow]{}[/COLOR]\n'.format(quality).encode('utf-8') +
            u'[I]Kết quả chỉ mang tính tham khảo[/I]'.encode('utf-8')
        )
        
    except Exception as e:
        log("Speed test error: {0}".format(str(e)), xbmc.LOGERROR)
        show_notification(u'Lỗi khi đo tốc độ'.encode('utf-8'))
    finally:
        dialog.close()
        try:
            if os.path.exists(test_file):
                os.remove(test_file)
        except:
            pass

def input_search():
    
    keyboard = xbmc.Keyboard('', u'Nhập từ khóa tìm kiếm'.encode('utf-8'))
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
    return None

def show_search_results(results):
    
    valid_extensions = ['.mkv', '.mp4', '.wmv', '.iso', '.ISO', '.ts']
    count = 0
    
    try:
        for item in results:
            try:
                name = item.get('name', '')
                url = item.get('url', '')
                size = float(item.get('size', 0))
                is_folder = item.get('file_type') == '0'

                linkcode = url.split('/')[-1].split('?')[0]
                
                if not is_folder:
                    ext = os.path.splitext(name)[1].lower()
                    if ext not in valid_extensions:
                        continue

                if '?' in url:
                    url = url.split('?')[0]

                li = xbmcgui.ListItem(name)
                li.setInfo('video', {
                    'Title': name,
                    'Size': size
                })

                li.setArt({
                    'icon': FSHARE_ICON,
                    'thumb': FSHARE_ICON,
                    'fanart': FANART_PATH
                })

                context_menu = []
                
                if not is_folder:
                    li.setProperty('IsPlayable', 'true')
                    context_menu.extend([
                        (u'[COLOR yellow]Xóa khỏi lịch sử[/COLOR]'.encode('utf-8'),
                         'RunPlugin({0}?mode=remove_input_history&url={1})'.format(
                             sys.argv[0], urllib.quote_plus(url))),
                        (u'[COLOR yellow]Xóa tất cả lịch sử[/COLOR]'.encode('utf-8'),
                         'RunPlugin({0}?mode=clear_input_history)'.format(sys.argv[0])),
                        (u'[COLOR lime]Tải xuống[/COLOR]'.encode('utf-8'),
                         'RunPlugin({0}?mode=download&url={1})'.format(
                             sys.argv[0], urllib.quote_plus(url))),
                        (u'[COLOR lime]Thêm vào yêu thích[/COLOR]'.encode('utf-8'),
                         'RunPlugin({0}?mode=add_favorite&linkcode={1})'.format(
                             sys.argv[0], urllib.quote_plus(linkcode)))
                    ])

                if context_menu:
                    li.addContextMenuItems(context_menu)

                query = {
                    'mode': 'play' if not is_folder else 'folder',
                    'url': url
                }
                
                xbmcplugin.addDirectoryItem(
                    handle=addon_handle,
                    url=build_url(query),
                    listitem=li,
                    isFolder=is_folder
                )
                count += 1
                
            except Exception as e:
                log("Error processing search result: {0}".format(str(e)), xbmc.LOGERROR)
                continue
                
        if count > 0:
            show_notification(u'Tìm thấy {0} kết quả'.format(count).encode('utf-8'))
        else:
            show_notification(u'Không tìm thấy kết quả phù hợp'.encode('utf-8'))
            
        xbmcplugin.endOfDirectory(addon_handle)
        
    except Exception as e:
        log("Error showing search results: {0}".format(str(e)), xbmc.LOGERROR)
        show_notification(u'Lỗi hiển thị kết quả tìm kiếm'.encode('utf-8'))

def get_search_history():
    
    if addon.getSetting('save_search_history') != 'true':
        return []
        
    history = addon.getSetting('search_history')
    return history.split('|') if history else []

def add_to_search_history(keyword):
    
    if addon.getSetting('save_search_history') != 'true':
        return
        
    history = get_search_history()

    if keyword in history:
        history.remove(keyword)

    history.insert(0, keyword)

    max_items = int(addon.getSetting('max_search_history'))
    history = history[:max_items]

    addon.setSetting('search_history', '|'.join(history))

def remove_from_search_history(keyword):
    
    history = get_search_history()
    if keyword in history:
        history.remove(keyword)
        addon.setSetting('search_history', '|'.join(history))
        xbmc.executebuiltin('Container.Refresh')

def show_search_menu():
    
    add_dir(u"[COLOR yellow]Tìm kiếm mới[/COLOR]".encode('utf-8'), "new_search", SEARCH_ICON)
    add_dir(u"Top Files tìm kiếm".encode('utf-8'), "top_files", TOPFILES_ICON)

    history = get_search_history()
    for keyword in history:
        li = xbmcgui.ListItem(keyword)

        context_menu = [
            (u'[COLOR yellow]Xóa khỏi lịch sử[/COLOR]'.encode('utf-8'),
             'RunPlugin({0}?mode=remove_search_history&keyword={1})'.format(
                 sys.argv[0], urllib.quote_plus(keyword))),
            (u'[COLOR yellow]Xóa tất cả lịch sử[/COLOR]'.encode('utf-8'),
             'RunPlugin({0}?mode=clear_search_history)'.format(sys.argv[0]))
        ]
        li.addContextMenuItems(context_menu)
        
        url = build_url({
            'mode': 'search',
            'keyword': keyword
        })
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=url,
            listitem=li,
            isFolder=True
        )
    
    xbmcplugin.endOfDirectory(addon_handle)

def clear_input_history():

    if xbmcgui.Dialog().yesno(
        u'Xác nhận'.encode('utf-8'),
        u'Bạn có chắc muốn xóa toàn bộ lịch sử nhập link?'.encode('utf-8')
    ):
        addon.setSetting('input_history', '')
        show_notification(u'Đã xóa toàn bộ lịch sử nhập link'.encode('utf-8'))
        xbmc.executebuiltin('Container.Refresh')

def clear_search_history():
    
    if xbmcgui.Dialog().yesno(
        u'Xác nhận'.encode('utf-8'),
        u'Bạn có chắc muốn xóa toàn bộ lịch sử tìm kiếm?'.encode('utf-8')
    ):
        addon.setSetting('search_history', '')
        show_notification(u'Đã xóa toàn bộ lịch sử tìm kiếm'.encode('utf-8'))
        xbmc.executebuiltin('Container.Refresh')

def show_settings_menu():

    add_dir(u"Cài đặt tài khoản".encode('utf-8'), "openSettings", USER_ICON)

    add_dir(u"Thông tin tài khoản".encode('utf-8'), "account_info", INFO_ICON)

    add_dir(u"Cập nhật tài khoản".encode('utf-8'), "update_account", CAPNHAT_ICON)
    
    xbmcplugin.endOfDirectory(addon_handle)

def process_url_for_history(final_url):
    
    try:
        if is_google_sheet_url(final_url):

            from resources.lib.gsheet import get_sheet_title, get_sheet_data
            sheet_title = get_sheet_title(final_url)
            
            if not sheet_title:

                items = get_sheet_data(final_url)
                if items and len(items) > 0:
                    sheet_title = items[0]['name']
                else:
                    sheet_title = "Google Sheet"

            add_to_input_history(sheet_title, final_url)
            process_fshare_url(final_url)
        else:

            name, file_type, size = fshare.get_file_info(final_url)
            if name:
                add_to_input_history(name, final_url)
                process_fshare_url(final_url)
            else:
                show_notification(u'Không thể lấy thông tin file/folder'.encode('utf-8'))
    except Exception as e:
        log("Process URL error: {0}".format(str(e)), xbmc.LOGERROR)
        show_notification(u'Lỗi xử lý link'.encode('utf-8'))

def get_play_history():
    
    if addon.getSetting('save_play_history') != 'true':
        return []
        
    history = addon.getSetting('play_history')
    return history.split('||') if history else []

def add_to_play_history(name, url, size):
    
    if addon.getSetting('save_play_history') != 'true':
        return
        
    history = get_play_history()
    entry = '{0}|{1}|{2}'.format(name, url, size)

    history = [h for h in history if h.split('|')[1] != url]

    history.insert(0, entry)

    max_items = int(addon.getSetting('max_play_history'))
    history = history[:max_items]

    addon.setSetting('play_history', '||'.join(history))

def remove_from_play_history(url):
    
    history = get_play_history()
    history = [h for h in history if h.split('|')[1] != url]
    addon.setSetting('play_history', '||'.join(history))
    xbmc.executebuiltin('Container.Refresh')

def clear_play_history():
    
    if xbmcgui.Dialog().yesno(
        u'Xác nhận'.encode('utf-8'),
        u'Bạn có chắc muốn xóa toàn bộ lịch sử xem?'.encode('utf-8')
    ):
        addon.setSetting('play_history', '')
        show_notification(u'Đã xóa toàn bộ lịch sử xem'.encode('utf-8'))
        xbmc.executebuiltin('Container.Refresh')

def show_play_history():
    
    history = get_play_history()
    for entry in history:
        try:
            name, url, size = entry.split('|')
            size = float(size)

            li = xbmcgui.ListItem(name)

            li.setInfo('video', {
                'Title': name,
                'Size': size
            })
            
            li.setArt({
                'icon': FSHARE_ICON,
                'thumb': FSHARE_ICON,
                'fanart': FANART_PATH
            })

            context_menu = [
                (u'[COLOR yellow]Xóa khỏi lịch sử[/COLOR]'.encode('utf-8'),
                 'RunPlugin({0}?mode=remove_play_history&url={1})'.format(
                     sys.argv[0], urllib.quote_plus(url))),
                (u'[COLOR yellow]Xóa tất cả lịch sử[/COLOR]'.encode('utf-8'),
                 'RunPlugin({0}?mode=clear_play_history)'.format(sys.argv[0])),
                (u'[COLOR lime]Tải xuống[/COLOR]'.encode('utf-8'),
                 'RunPlugin({0}?mode=download&url={1})'.format(
                     sys.argv[0], urllib.quote_plus(url))),
                (u'[COLOR lime]Thêm vào yêu thích[/COLOR]'.encode('utf-8'),
                 'RunPlugin({0}?mode=add_favorite&linkcode={1})'.format(
                     sys.argv[0], urllib.quote_plus(url.split('/')[-1])))
            ]
            
            li.addContextMenuItems(context_menu)

            query = {
                'mode': 'play',
                'url': url
            }
            
            xbmcplugin.addDirectoryItem(
                handle=addon_handle,
                url=build_url(query),
                listitem=li,
                isFolder=False
            )
        except:
            continue
            
    xbmcplugin.endOfDirectory(addon_handle)

def show_my_files_menu():

    add_dir(u"Home folders".encode('utf-8'), "home_folders", FILES_ICON)

    download_path = addon.getSetting('download_path')
    if download_path:
        add_dir(u"My download".encode('utf-8'), "my_download", MYFILES_ICON)
    
    xbmcplugin.endOfDirectory(addon_handle)

def show_my_download():
    
    download_path = addon.getSetting('download_path')
    if not download_path:
        show_notification(u'Chưa thiết lập thư mục tải xuống'.encode('utf-8'))
        return
        
    try:

        files = os.listdir(download_path)
        for filename in files:
            filepath = os.path.join(download_path, filename)
            if os.path.isfile(filepath):  # Chỉ hiển thị file, không hiển thị thư mục

                size = os.path.getsize(filepath)
                
                li = xbmcgui.ListItem(filename)

                li.setInfo('video', {
                    'Title': filename,
                    'Size': size
                })
                
                li.setArt({
                    'icon': FSHARE_ICON,
                    'thumb': FSHARE_ICON,
                    'fanart': FANART_PATH
                })

                context_menu = [
                    (u'[COLOR yellow]Xóa file này[/COLOR]'.encode('utf-8'),
                     'RunPlugin({0}?mode=remove_local_file&path={1})'.format(
                         sys.argv[0], urllib.quote_plus(filepath))),
                    (u'[COLOR yellow]Xóa tất cả file[/COLOR]'.encode('utf-8'),
                     'RunPlugin({0}?mode=clear_download_folder)'.format(sys.argv[0]))
                ]
                
                li.addContextMenuItems(context_menu)

                url = build_url({
                    'mode': 'play_local',
                    'path': filepath
                })
                
                xbmcplugin.addDirectoryItem(
                    handle=addon_handle,
                    url=url,
                    listitem=li,
                    isFolder=False
                )
                
        xbmcplugin.endOfDirectory(addon_handle)
        
    except Exception as e:
        log("Show download folder error: {0}".format(str(e)), xbmc.LOGERROR)
        show_notification(u'Lỗi hiển thị thư mục tải xuống'.encode('utf-8'))

def play_local_file(filepath):
    
    try:
        play_item = xbmcgui.ListItem(path=filepath)
        play_item.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(addon_handle, True, play_item)
    except:
        show_notification(u'Lỗi phát file'.encode('utf-8'))

def remove_local_file(filepath):
    
    try:
        os.remove(filepath)
        show_notification(u'Đã xóa file'.encode('utf-8'))
        xbmc.executebuiltin('Container.Refresh')
    except:
        show_notification(u'Lỗi xóa file'.encode('utf-8'))

def clear_download_folder():
    
    download_path = addon.getSetting('download_path')
    if not download_path:
        return
        
    if xbmcgui.Dialog().yesno(
        u'Xác nhận'.encode('utf-8'),
        u'Bạn có chắc muốn xóa tất cả file đã tải xuống?'.encode('utf-8')
    ):
        try:
            files = os.listdir(download_path)
            for filename in files:
                filepath = os.path.join(download_path, filename)
                if os.path.isfile(filepath):
                    os.remove(filepath)
            show_notification(u'Đã xóa tất cả file'.encode('utf-8'))
            xbmc.executebuiltin('Container.Refresh')
        except:
            show_notification(u'Lỗi xóa file'.encode('utf-8'))

def update_account():

    if xbmcgui.Dialog().yesno(
        u'Cảnh báo'.encode('utf-8'),
        u'Chỉ dùng sau khi thay đổi tài khoản mới, nếu không phải vừa đổi thì xin hãy thoát ra tránh mất một phiên đăng nhập.'.encode('utf-8'),
        nolabel=u'Thoát ra'.encode('utf-8'),
        yeslabel=u'Cập nhật'.encode('utf-8')
    ):

        username = addon.getSetting('username')
        password = addon.getSetting('password')
        result = fshare.login(username, password)
        
        if len(result) == 4:  # Đăng nhập thành công
            success, token, session_id, timelog = result

            addon.setSetting('tokenfshare', token)
            addon.setSetting('sessionfshare', session_id) 
            addon.setSetting('timelog', timelog)
            show_notification(u'Đã cập nhật thông tin tài khoản mới thành công'.encode('utf-8'))
        else:  # Đăng nhập thất bại
            success, token, session_id, timelog, message = result
            xbmcgui.Dialog().ok(
                u'Lỗi cập nhật'.encode('utf-8'),
                message.encode('utf-8')
            )

def main():
    mode = args.get('mode', None)
    if mode is None:
        show_main_menu()
        return
        
    mode = mode[0]
    
    if mode != 'settings' and not login():
        return

    elif mode == 'show_advertisement':
        path = args.get('path', [''])[0]
        title = args.get('title', [u'Quảng cáo'])[0]
        if path:
            show_advertisement_content(path, title)

    elif mode == 'input':
        if 'id' in args:

            short_id = args.get('id')[0]
            host = addon.getSetting('shorten_host')
            final_url = fshare.expand_shortened_url(short_id, host)
            if final_url:
                if 'fshare.vn' in final_url:
                    process_fshare_url(final_url)
                else:
                    play_video(final_url)
        else:

            show_input_menu()
    elif mode == 'my_files':
        show_my_files_menu()
    elif mode == 'home_folders':
        path = args.get('path', ['/'])[0]
        page = int(args.get('page', [0])[0])
        files, has_next = fshare.get_my_files(path, page_index=page)
        show_files(files, 'home_folders', path, page, has_next)
    elif mode == 'my_download':
        show_my_download()
    elif mode == 'play_local':
        path = args.get('path', [None])[0]
        if path:
            play_local_file(path)
    elif mode == 'favourites':
        page = int(args.get('page', [0])[0])
        files, has_next = fshare.get_favorites(page_index=page)
        show_files(files, 'favourites', '/', page, has_next)
    elif mode == 'top_files':
        show_top_files()
    elif mode == 'play':
        url = args.get('url', [None])[0]
        if url:
            play_video(url)
    elif mode == 'download':
        url = args.get('url', [None])[0]
        if url:
            download_file(url)
    elif mode == 'add_favorite':
        linkcode = args.get('linkcode', [None])[0]
        if linkcode:
            success, message = fshare.add_favorite(linkcode)
            show_notification(message.encode('utf-8'))
            if success:
                xbmc.executebuiltin('Container.Refresh')
    elif mode == 'remove_from_favorite':
        linkcode = args.get('linkcode', [None])[0]
        if linkcode:
            success, message = fshare.remove_from_favorite(linkcode)
            show_notification(message.encode('utf-8'))
            if success:
                xbmc.executebuiltin('Container.Refresh')
    elif mode == 'settings_menu':
        show_settings_menu()
    elif mode == 'account_info':
        show_account_info()
    elif mode == 'folder':
        url = args.get('url', [None])[0]
        page = int(args.get('page', [0])[0])
        if url:
            files, has_next = fshare.get_folder_list(url, page_index=page)
            show_files(files, 'folder', url, page, has_next)
    elif mode == 'top_follows':
        show_top_follows()
    elif mode == 'speed_test':
        speed_test()
    elif mode == 'search':
        if 'keyword' in args:

            keyword = args.get('keyword')[0]
            results = fshare.search_files(keyword)
            show_search_results(results)
        else:

            show_search_menu()
    elif mode == 'new_search':
        keyword = input_search()
        if keyword:
            add_to_search_history(keyword)
            results = fshare.search_files(keyword)
            show_search_results(results)
    elif mode == 'remove_search_history':
        keyword = args.get('keyword', [None])[0]
        if keyword:
            remove_from_search_history(keyword)
    elif mode == 'new_input':
        keyboard = xbmc.Keyboard('', u'Nhập ID rút gọn'.encode('utf-8'))
        keyboard.doModal()
        if keyboard.isConfirmed():
            short_id = keyboard.getText()
            if short_id:
                host = addon.getSetting('shorten_host')
                final_url = fshare.expand_shortened_url(short_id, host)
                if final_url:
                    if is_google_sheet_url(final_url) or 'fshare.vn' in final_url:
                        process_url_for_history(final_url)
                    else:
                        show_notification(u'Link không hợp lệ'.encode('utf-8'))
                else:
                    show_notification(u'Không thể mở rộng link rút gọn'.encode('utf-8'))
    elif mode == 'remove_input_history':
        url = args.get('url', [None])[0]
        if url:
            remove_from_input_history(url)
    elif mode == 'clear_input_history':
        clear_input_history()
    elif mode == 'clear_search_history':
        clear_search_history()
    elif mode == 'settings_menu':
        show_settings_menu()
    elif mode == 'process_url':
        url = args.get('url', [None])[0]
        if url:
            process_fshare_url(url)
    elif mode == 'play_history':
        show_play_history()
    elif mode == 'remove_play_history':
        url = args.get('url', [None])[0]
        if url:
            remove_from_play_history(url)
    elif mode == 'clear_play_history':
        clear_play_history()
    elif mode == 'openSettings':
        addon.openSettings()
        xbmc.executebuiltin('Container.Refresh')
    elif mode == 'remove_local_file':
        path = args.get('path', [None])[0]
        if path:
            remove_local_file(path)
    elif mode == 'clear_download_folder':
        clear_download_folder()
    elif mode == 'update_account':
        update_account()

if __name__ == '__main__':
    main()
